#!/usr/bin/env bash
set -euo pipefail
pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$HOME/Library/Audio/Plug-Ins/Components" "$HOME/Library/Audio/Plug-Ins/VST3" "$HOME/Applications"
ditto "$pkg_root/build-artefacts/Sattari Auto Pitch.component" "$HOME/Library/Audio/Plug-Ins/Components/Sattari Auto Pitch.component"
ditto "$pkg_root/build-artefacts/Sattari Auto Pitch.vst3" "$HOME/Library/Audio/Plug-Ins/VST3/Sattari Auto Pitch.vst3"
ditto "$pkg_root/build-artefacts/Sattari Auto Pitch.app" "$HOME/Applications/Sattari Auto Pitch.app"
echo "Installed Sattari Auto Pitch realtime alpha to user plugin folders. Rescan plugins in your DAW."
