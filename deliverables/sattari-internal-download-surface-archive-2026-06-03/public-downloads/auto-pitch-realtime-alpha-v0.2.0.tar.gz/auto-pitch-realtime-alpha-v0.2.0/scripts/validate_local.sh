#!/usr/bin/env bash
set -euo pipefail
pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for item in "$pkg_root"/build-artefacts/*; do
  [[ -e "$item" ]] || continue
  codesign --verify --deep --strict --verbose=2 "$item"
done
if command -v auval >/dev/null 2>&1; then
  auval -v aufx Ap01 Satr
fi
if [[ -x /Applications/pluginval.app/Contents/MacOS/pluginval ]]; then
  /Applications/pluginval.app/Contents/MacOS/pluginval --validate-in-process --strictness-level 5 "$pkg_root/build-artefacts/Sattari Auto Pitch.vst3"
fi
