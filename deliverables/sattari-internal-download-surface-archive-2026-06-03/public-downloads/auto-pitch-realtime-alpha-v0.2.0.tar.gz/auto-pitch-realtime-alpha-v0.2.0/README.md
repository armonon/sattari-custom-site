# Sattari Auto Pitch realtime alpha v0.2.0

Truth label: internal alpha for Armon/testing. Not sale-ready, not notarized, and not final vocal-quality proof.

## What changed

This build is no longer a pass-through shell. It adds a realtime monophonic tuning path:

- live pitch detection on vocal input
- nearest-note snapping to selected key/scale
- Natural / Modern / Hard correction behavior
- Amount, Speed, Do No Harm, Correction On, and AutoKey Follow controls
- Rubber Band realtime pitch-shift engine bundled inside the AU/VST3/app
- trace import still works for offline AutoKey/Pitch Compass JSON

## Install

Run `scripts/install_user_plugins.sh` or use the Mac `.pkg` installer if provided.

## Current limitations

- Monophonic vocal tuning alpha only.
- AutoKey Follow is an early histogram follower, not final Adapt Mode.
- Real-vocal listening/artifact review still required before public beta.
- Package is ad-hoc signed, not Apple Developer ID notarized.
