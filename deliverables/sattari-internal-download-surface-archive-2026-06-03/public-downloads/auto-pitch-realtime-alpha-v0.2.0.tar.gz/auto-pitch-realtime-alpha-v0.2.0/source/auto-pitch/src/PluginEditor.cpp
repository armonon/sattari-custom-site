#include "PluginEditor.h"

void PitchCompassStub::paint (juce::Graphics& g)
{
    auto area = getLocalBounds().toFloat().reduced (8.0f);
    g.setColour (juce::Colour (0xff10131f));
    g.fillRoundedRectangle (area, 14.0f);
    g.setColour (juce::Colour (0xff6b8cff));
    g.drawRoundedRectangle (area, 14.0f, 1.5f);

    const juce::StringArray notes { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    const auto centre = area.getCentre();
    const float radius = juce::jmin (area.getWidth(), area.getHeight()) * 0.34f;

    g.setFont (juce::FontOptions (13.0f, juce::Font::bold));
    for (int i = 0; i < notes.size(); ++i)
    {
        const float angle = juce::MathConstants<float>::twoPi * ((float) i / (float) notes.size()) - juce::MathConstants<float>::halfPi;
        const auto x = centre.x + std::cos (angle) * radius;
        const auto y = centre.y + std::sin (angle) * radius;
        juce::Rectangle<float> noteBounds (x - 16.0f, y - 10.0f, 32.0f, 20.0f);
        g.setColour ((i == 9 || i == 0 || i == 2 || i == 4 || i == 5 || i == 7 || i == 11)
            ? juce::Colour (0xffffc7a8)
            : juce::Colour (0xff51586d));
        g.drawFittedText (notes[i], noteBounds.toNearestInt(), juce::Justification::centred, 1);
    }

    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    g.drawFittedText ("Pitch Compass", area.toNearestInt().withHeight (24), juce::Justification::centred, 1);
    g.setFont (juce::FontOptions (12.0f));
    g.setColour (juce::Colours::lightgrey);
    g.drawFittedText ("stub: trace contract maps key + note weights", area.toNearestInt().removeFromBottom (28), juce::Justification::centred, 2);
}

SattariAutoPitchAudioProcessorEditor::SattariAutoPitchAudioProcessorEditor (SattariAutoPitchAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setSize (820, 500);

    title.setText ("Sattari Auto Pitch", juce::dontSendNotification);
    title.setFont (juce::FontOptions (30.0f, juce::Font::bold));
    title.setColour (juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible (title);

    subtitle.setText ("Realtime AutoTune alpha: pitch detect → scale snap → Rubber Band correction", juce::dontSendNotification);
    subtitle.setColour (juce::Label::textColourId, juce::Colours::lightgrey);
    addAndMakeVisible (subtitle);

    setupCombo (keyRoot);
    keyRoot.addItemList (juce::StringArray { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }, 1);
    setupCombo (scale);
    scale.addItemList (juce::StringArray { "major", "minor", "chromatic" }, 1);
    setupCombo (style);
    style.addItemList (juce::StringArray { "natural", "modern", "hard" }, 1);

    setupSlider (amount, "%");
    setupSlider (speed, "%");
    setupSlider (inputGain, " dB");
    setupSlider (outputGain, " dB");
    setupSlider (traceConfidence, "%");
    traceConfidence.setEnabled (false);

    amount.textFromValueFunction = [] (double value) { return juce::String ((int) std::round (value * 100.0)) + "%"; };
    speed.textFromValueFunction = [] (double value) { return juce::String ((int) std::round (value * 100.0)) + "%"; };
    traceConfidence.textFromValueFunction = [] (double value) { return juce::String ((int) std::round (value * 100.0)) + "%"; };

    enableCorrection.setButtonText ("Correction on");
    enableCorrection.setColour (juce::ToggleButton::textColourId, juce::Colours::white);
    addAndMakeVisible (enableCorrection);

    autoKey.setButtonText ("AutoKey follow");
    autoKey.setColour (juce::ToggleButton::textColourId, juce::Colours::white);
    autoKey.setTooltip ("Reserved alpha control: current build uses imported/offline trace keys or the selected key.");
    addAndMakeVisible (autoKey);

    doNoHarm.setButtonText ("Do No Harm guardrail");
    doNoHarm.setColour (juce::ToggleButton::textColourId, juce::Colours::white);
    addAndMakeVisible (doNoHarm);

    loadTraceButton.onClick = [this] { loadTraceFromClipboard(); };
    addAndMakeVisible (loadTraceButton);

    setupLabel (keyLabel, "Key / Style");
    setupLabel (correctionLabel, "Correction");
    setupLabel (gainLabel, "Utility");
    setupLabel (traceLabel, "Trace contract");
    traceStatus.setColour (juce::Label::textColourId, juce::Colours::lightgrey);
    traceStatus.setJustificationType (juce::Justification::centredLeft);
    traceStatus.setText (audioProcessor.getLiveStatusSummary(), juce::dontSendNotification);
    addAndMakeVisible (traceStatus);
    addAndMakeVisible (pitchCompass);

    auto& params = audioProcessor.parameters();
    keyRootAttach = std::make_unique<ComboAttachment> (params, "keyRoot", keyRoot);
    scaleAttach = std::make_unique<ComboAttachment> (params, "scale", scale);
    styleAttach = std::make_unique<ComboAttachment> (params, "style", style);
    amountAttach = std::make_unique<SliderAttachment> (params, "amount", amount);
    speedAttach = std::make_unique<SliderAttachment> (params, "speed", speed);
    inputGainAttach = std::make_unique<SliderAttachment> (params, "inputGain", inputGain);
    outputGainAttach = std::make_unique<SliderAttachment> (params, "outputGain", outputGain);
    traceConfidenceAttach = std::make_unique<SliderAttachment> (params, "traceConfidence", traceConfidence);
    doNoHarmAttach = std::make_unique<ButtonAttachment> (params, "doNoHarm", doNoHarm);
    enableCorrectionAttach = std::make_unique<ButtonAttachment> (params, "enableCorrection", enableCorrection);
    autoKeyAttach = std::make_unique<ButtonAttachment> (params, "autoKey", autoKey);

    startTimerHz (4);
}

void SattariAutoPitchAudioProcessorEditor::setupSlider (juce::Slider& s, const juce::String& suffix)
{
    s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 76, 22);
    s.setTextValueSuffix (suffix);
    s.setColour (juce::Slider::rotarySliderFillColourId, juce::Colour (0xffff6b35));
    s.setColour (juce::Slider::thumbColourId, juce::Colours::white);
    s.setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
    addAndMakeVisible (s);
}

void SattariAutoPitchAudioProcessorEditor::setupCombo (juce::ComboBox& c)
{
    c.setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff171821));
    c.setColour (juce::ComboBox::textColourId, juce::Colours::white);
    c.setColour (juce::ComboBox::outlineColourId, juce::Colour (0xffff6b35));
    addAndMakeVisible (c);
}

void SattariAutoPitchAudioProcessorEditor::setupLabel (juce::Label& label, const juce::String& text, float size)
{
    label.setText (text, juce::dontSendNotification);
    label.setFont (juce::FontOptions (size, juce::Font::bold));
    label.setColour (juce::Label::textColourId, juce::Colour (0xffffc7a8));
    addAndMakeVisible (label);
}

void SattariAutoPitchAudioProcessorEditor::loadTraceFromClipboard()
{
    const auto traceJson = juce::SystemClipboard::getTextFromClipboard();
    const bool ok = audioProcessor.applyTraceContractJson (traceJson);
    traceStatus.setColour (juce::Label::textColourId, ok ? juce::Colours::lightgreen : juce::Colours::orange);
    traceStatus.setText (audioProcessor.getLastTraceSummary(), juce::sendNotificationSync);
}

void SattariAutoPitchAudioProcessorEditor::timerCallback()
{
    traceStatus.setText (audioProcessor.getLiveStatusSummary(), juce::dontSendNotification);
}

void SattariAutoPitchAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff07080d));
    auto area = getLocalBounds().toFloat().reduced (14.0f);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff201225), area.getTopLeft(),
                                             juce::Colour (0xff071827), area.getBottomRight(), false));
    g.fillRoundedRectangle (area, 18.0f);

    g.setColour (juce::Colour (0xffff6b35));
    g.drawRoundedRectangle (area, 18.0f, 1.5f);
}

void SattariAutoPitchAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (28);
    title.setBounds (area.removeFromTop (38));
    subtitle.setBounds (area.removeFromTop (26));
    area.removeFromTop (12);

    auto main = area;
    auto left = main.removeFromLeft (475);
    main.removeFromLeft (18);
    auto right = main;

    keyLabel.setBounds (left.removeFromTop (22));
    auto keyRow = left.removeFromTop (44);
    keyRoot.setBounds (keyRow.removeFromLeft (90));
    keyRow.removeFromLeft (10);
    scale.setBounds (keyRow.removeFromLeft (120));
    keyRow.removeFromLeft (10);
    style.setBounds (keyRow.removeFromLeft (120));

    left.removeFromTop (8);
    auto toggleRow = left.removeFromTop (28);
    enableCorrection.setBounds (toggleRow.removeFromLeft (140));
    autoKey.setBounds (toggleRow.removeFromLeft (130));
    doNoHarm.setBounds (toggleRow);

    left.removeFromTop (12);
    correctionLabel.setBounds (left.removeFromTop (22));
    auto correctionRow = left.removeFromTop (128);
    amount.setBounds (correctionRow.removeFromLeft (105));
    speed.setBounds (correctionRow.removeFromLeft (105));
    traceConfidence.setBounds (correctionRow.removeFromLeft (125));

    left.removeFromTop (18);
    gainLabel.setBounds (left.removeFromTop (22));
    auto gainRow = left.removeFromTop (128);
    inputGain.setBounds (gainRow.removeFromLeft (105));
    outputGain.setBounds (gainRow.removeFromLeft (105));

    traceLabel.setBounds (right.removeFromTop (22));
    pitchCompass.setBounds (right.removeFromTop (260));
    right.removeFromTop (12);
    loadTraceButton.setBounds (right.removeFromTop (38));
    right.removeFromTop (8);
    traceStatus.setBounds (right.removeFromTop (72));
}
