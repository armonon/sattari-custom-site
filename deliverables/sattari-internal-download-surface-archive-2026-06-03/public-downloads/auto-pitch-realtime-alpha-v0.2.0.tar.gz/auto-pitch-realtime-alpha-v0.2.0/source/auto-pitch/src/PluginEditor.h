#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class PitchCompassStub final : public juce::Component
{
public:
    PitchCompassStub() = default;
    void paint (juce::Graphics&) override;
};

class SattariAutoPitchAudioProcessorEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit SattariAutoPitchAudioProcessorEditor (SattariAutoPitchAudioProcessor&);
    ~SattariAutoPitchAudioProcessorEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    void timerCallback() override;
    void setupSlider (juce::Slider&, const juce::String& suffix = {});
    void setupCombo (juce::ComboBox&);
    void setupLabel (juce::Label&, const juce::String& text, float size = 14.0f);
    void loadTraceFromClipboard();

    SattariAutoPitchAudioProcessor& audioProcessor;

    juce::Label title, subtitle, keyLabel, correctionLabel, gainLabel, traceLabel, traceStatus;
    juce::ComboBox keyRoot, scale, style;
    juce::Slider amount, speed, inputGain, outputGain, traceConfidence;
    juce::ToggleButton doNoHarm, enableCorrection, autoKey;
    juce::TextButton loadTraceButton { "Load trace JSON from clipboard" };
    PitchCompassStub pitchCompass;

    std::unique_ptr<ComboAttachment> keyRootAttach, scaleAttach, styleAttach;
    std::unique_ptr<SliderAttachment> amountAttach, speedAttach, inputGainAttach, outputGainAttach, traceConfidenceAttach;
    std::unique_ptr<ButtonAttachment> doNoHarmAttach, enableCorrectionAttach, autoKeyAttach;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SattariAutoPitchAudioProcessorEditor)
};
