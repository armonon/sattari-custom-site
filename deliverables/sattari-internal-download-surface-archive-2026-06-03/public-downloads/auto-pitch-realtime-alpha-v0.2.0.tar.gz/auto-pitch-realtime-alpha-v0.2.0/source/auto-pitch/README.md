# Sattari Auto Pitch

Internal JUCE shell for the Auto Pitch flagship lane.

## Truth label

This is a local AU/VST3/Standalone plugin shell only. It exposes the control surface and trace-contract handoff for the existing `prototypes/auto-pitch` offline engine, but it does **not** perform production vocal correction yet and is not a beta, public demo, or sale-ready package.

## Current scope

- Audio effect plugin that passes input audio through with input/output gain.
- UI controls for Key Root, Scale, Style, Amount, Speed, Do No Harm, and trace confidence.
- Stub Pitch Compass panel for the 12-note contract.
- Clipboard trace import path for JSON traces shaped like `prototypes/auto-pitch/out/demo-modern-trace.json`.
- Fixture contract smoke test: `python3 scripts/auto_pitch_trace_contract_check.py`.

## Next gates

1. Compile AU/VST3/Standalone locally.
2. Connect the trace-contract state to a real-time monitor path.
3. Port/extract the Python DSP contract into C++ or a safe reference bridge, then remove Python from production builds.
4. Run real vocal corpus validation on at least five owned/cleared/public-domain dry vocal clips before any stronger vocal-quality claim.
5. Run manual DAW/listening validation before beta/public/sale-ready language.

## Non-goals

- No Antares-quality claim.
- No public release claim.
- No paid beta.
- No bundled copyrighted/uncleared vocal material.
