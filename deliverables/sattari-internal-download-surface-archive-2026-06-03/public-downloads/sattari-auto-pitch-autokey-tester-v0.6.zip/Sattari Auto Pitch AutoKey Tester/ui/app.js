const traces = window.AUTO_PITCH_TRACES || {};
const order = ["natural", "modern", "hard"];
const noteNames = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
const styleMeta = {
  natural: {
    color: "#7cffc9",
    title: "Natural Pop",
    copy: "Gentle correction that moves pitch centers while leaving scoops, bends, and vibrato emotionally intact."
  },
  modern: {
    color: "#76a7ff",
    title: "Modern Tight",
    copy: "A confident, current vocal sound: tighter notes and faster pull without fully flattening the phrase."
  },
  hard: {
    color: "#ff5dd6",
    title: "Hard Tune",
    copy: "Intentional lock-in for the Auto-Tune effect, still guarded by confidence so uncertain frames do not glitch."
  }
};

let selectedStyle = "natural";

const svgNS = "http://www.w3.org/2000/svg";
function el(name, attrs = {}, children = []) {
  const node = document.createElementNS(svgNS, name);
  Object.entries(attrs).forEach(([key, value]) => {
    if (value !== undefined && value !== null) node.setAttribute(key, value);
  });
  children.forEach(child => node.appendChild(child));
  return node;
}
function htmlEscape(value) {
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[char]));
}
function setText(id, text) { document.getElementById(id).textContent = text; }
function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
function midiToNote(midi) {
  if (midi === null || midi === undefined || Number.isNaN(midi)) return "—";
  const rounded = Math.round(midi);
  return `${noteNames[((rounded % 12) + 12) % 12]}${Math.floor(rounded / 12) - 1}`;
}
function pathFrom(points, xFn, yFn) {
  return points.map((point, index) => `${index === 0 ? "M" : "L"}${xFn(point).toFixed(2)},${yFn(point).toFixed(2)}`).join(" ");
}
function metric(label, value) {
  return `<div class="metric"><span>${htmlEscape(label)}</span><strong>${htmlEscape(value)}</strong></div>`;
}
function guarded(frame) {
  return (frame.guardrails && frame.guardrails.length) || (frame.protection_flags && frame.protection_flags.length) || frame.do_no_harm_strength < 0.92 || frame.confidence < 0.78;
}
function protectedFrame(frame) {
  return (frame.protection_flags && frame.protection_flags.length) || frame.render_action === "copy_source";
}
function segmentColor(frame) {
  const segment = frame.segment_label || "voiced";
  if (segment === "consonant") return "rgba(105,230,255,0.78)";
  if (segment === "breath") return "rgba(124,255,201,0.56)";
  if (segment === "silence") return "rgba(255,255,255,0.20)";
  if (segment === "unvoiced") return "rgba(183,140,255,0.52)";
  if (segment === "voiced_low_confidence") return "rgba(255,184,77,0.72)";
  return "rgba(79,243,141,0.30)";
}
function allFrames() { return order.flatMap(style => traces[style]?.trace || []); }
function allMidiValues() {
  const values = allFrames().flatMap(frame => [frame.source_midi, frame.corrected_hz ? 69 + 12 * Math.log2(frame.corrected_hz / 440) : null, frame.target_midi]).filter(Number.isFinite);
  return values.length ? values : [57, 69];
}
function correctedMidi(frame) {
  return frame.corrected_hz ? 69 + 12 * Math.log2(frame.corrected_hz / 440) : frame.source_midi;
}
function pitchDrawable(frame) {
  return Number.isFinite(frame.source_midi) && Number.isFinite(frame.target_midi) && Number.isFinite(correctedMidi(frame));
}

function render() {
  const data = traces[selectedStyle];
  if (!data) return;
  const meta = styleMeta[selectedStyle];

  document.querySelectorAll(".style-button").forEach(button => button.classList.toggle("active", button.dataset.style === selectedStyle));
  setText("style-title", data.settings.style_label || meta.title);
  setText("style-copy", meta.copy);
  document.documentElement.style.setProperty("--corrected", meta.color);

  const summary = data.summary;
  document.getElementById("metrics").innerHTML = [
    metric("Avg pull", `${summary.avg_abs_correction_cents.toFixed(1)}¢`),
    metric("Max pull", `${summary.max_abs_correction_cents.toFixed(1)}¢`),
    metric("Do No Harm", `${summary.do_no_harm_events} frames`),
    metric("Protected", `${summary.protected_region_count || 0} frames`),
    metric("Adaptive saves", `${summary.adaptive_events} events`)
  ].join("");
  setText("confidence-value", `${Math.round(summary.avg_confidence * 100)}%`);
  document.getElementById("confidence-fill").style.width = `${Math.round(summary.avg_confidence * 100)}%`;

  renderCompass(data);
  renderTraceChart(data);
  renderComparisonChart();
  renderStyleCards();
}

function renderCompass(data) {
  const svg = document.getElementById("compass");
  svg.replaceChildren();

  const cx = 210, cy = 210;
  const ringR = 142;
  const notes = data.pitch_compass.notes;
  const maxWeight = Math.max(...notes.map(note => note.histogram_weight), 0.001);

  const defs = el("defs");
  const filter = el("filter", { id: "glow", x: "-50%", y: "-50%", width: "200%", height: "200%" });
  filter.appendChild(el("feGaussianBlur", { stdDeviation: "4", result: "blur" }));
  filter.appendChild(el("feMerge", {}, [el("feMergeNode", { in: "blur" }), el("feMergeNode", { in: "SourceGraphic" })]));
  defs.appendChild(filter);
  svg.appendChild(defs);

  svg.appendChild(el("circle", { cx, cy, r: 174, fill: "rgba(255,255,255,0.025)", stroke: "rgba(255,255,255,0.09)" }));
  svg.appendChild(el("circle", { cx, cy, r: ringR, fill: "none", stroke: "rgba(255,255,255,0.14)", "stroke-dasharray": "2 10" }));
  svg.appendChild(el("circle", { cx, cy, r: 76, fill: "rgba(66,245,212,0.04)", stroke: "rgba(66,245,212,0.14)" }));

  notes.forEach((note, index) => {
    const angle = (index / 12) * Math.PI * 2 - Math.PI / 2;
    const x = cx + Math.cos(angle) * ringR;
    const y = cy + Math.sin(angle) * ringR;
    const weight = note.histogram_weight / maxWeight;
    const radius = note.enabled ? 10 + weight * 17 : 5 + weight * 7;
    const isRoot = note.name === data.pitch_compass.root;
    svg.appendChild(el("line", { x1: cx, y1: cy, x2: x, y2: y, stroke: note.enabled ? "rgba(124,255,201,0.18)" : "rgba(255,255,255,0.05)", "stroke-width": note.enabled ? 1.4 : 0.8 }));
    svg.appendChild(el("circle", {
      cx: x, cy: y, r: radius,
      fill: note.enabled ? (isRoot ? "rgba(255,93,214,0.9)" : "rgba(124,255,201,0.82)") : "rgba(255,255,255,0.08)",
      stroke: note.enabled ? "rgba(255,255,255,0.75)" : "rgba(255,255,255,0.18)",
      "stroke-width": isRoot ? 2.5 : 1,
      filter: note.enabled ? "url(#glow)" : undefined
    }));
    const label = el("text", {
      x: cx + Math.cos(angle) * 184,
      y: cy + Math.sin(angle) * 184 + 5,
      "text-anchor": "middle",
      fill: note.enabled ? "#f8f4ff" : "#777487",
      "font-size": isRoot ? 18 : 13,
      "font-weight": isRoot ? 900 : 750
    });
    label.textContent = note.name;
    svg.appendChild(label);
  });

  const sampled = data.trace.filter(pitchDrawable).filter((_, index) => index % 3 === 0);
  const sourcePath = sampled.map(frame => {
    const pc = ((frame.source_midi % 12) + 12) % 12;
    const angle = (pc / 12) * Math.PI * 2 - Math.PI / 2;
    const r = 92 + (1 - frame.confidence) * 52 + Math.min(Math.abs(frame.target_error_cents || 0), 100) * 0.13;
    return { x: cx + Math.cos(angle) * r, y: cy + Math.sin(angle) * r };
  });
  svg.appendChild(el("path", { d: pathFrom(sourcePath, p => p.x, p => p.y), fill: "none", stroke: "rgba(255,255,255,0.78)", "stroke-width": 2.2, "stroke-linecap": "round", "stroke-linejoin": "round" }));

  sampled.filter((_, index) => index % 3 === 0).forEach(frame => {
    const sourcePc = ((frame.source_midi % 12) + 12) % 12;
    const targetPc = ((frame.target_midi % 12) + 12) % 12;
    const sourceAngle = (sourcePc / 12) * Math.PI * 2 - Math.PI / 2;
    const targetAngle = (targetPc / 12) * Math.PI * 2 - Math.PI / 2;
    const sx = cx + Math.cos(sourceAngle) * 104;
    const sy = cy + Math.sin(sourceAngle) * 104;
    const tx = cx + Math.cos(targetAngle) * 138;
    const ty = cy + Math.sin(targetAngle) * 138;
    svg.appendChild(el("line", {
      x1: sx, y1: sy, x2: tx, y2: ty,
      stroke: guarded(frame) ? "rgba(255,184,77,0.42)" : "rgba(66,245,212,0.42)",
      "stroke-width": clamp(Math.abs(frame.correction_cents) / 28, 0.6, 3.4),
      "stroke-linecap": "round"
    }));
  });

  const center = el("text", { x: cx, y: cy - 8, "text-anchor": "middle", fill: "#f8f4ff", "font-size": 38, "font-weight": 950 });
  center.textContent = `${data.settings.root} ${data.settings.scale}`;
  svg.appendChild(center);
  const sub = el("text", { x: cx, y: cy + 26, "text-anchor": "middle", fill: "#a9a5b8", "font-size": 13, "font-weight": 760 });
  sub.textContent = "target wells + sung orbit";
  svg.appendChild(sub);
}

function chartScales(frames, width, height, margin) {
  const midiValues = allMidiValues();
  const minMidi = Math.floor(Math.min(...midiValues) - 1.5);
  const maxMidi = Math.ceil(Math.max(...midiValues) + 1.5);
  const minTime = frames[0].time;
  const maxTime = frames[frames.length - 1].time;
  const x = frame => margin.left + ((frame.time - minTime) / (maxTime - minTime || 1)) * (width - margin.left - margin.right);
  const yValue = midi => margin.top + (1 - ((midi - minMidi) / (maxMidi - minMidi || 1))) * (height - margin.top - margin.bottom);
  return { minMidi, maxMidi, x, yValue, innerWidth: width - margin.left - margin.right, innerHeight: height - margin.top - margin.bottom };
}

function drawGrid(svg, scales, width, height, margin, rootScaleNotes = []) {
  for (let midi = scales.minMidi; midi <= scales.maxMidi; midi++) {
    const y = scales.yValue(midi);
    const pc = ((midi % 12) + 12) % 12;
    const inScale = rootScaleNotes.includes(noteNames[pc]);
    svg.appendChild(el("line", { x1: margin.left, y1: y, x2: width - margin.right, y2: y, stroke: inScale ? "rgba(124,255,201,0.12)" : "rgba(255,255,255,0.045)", "stroke-width": inScale ? 1.1 : 0.8 }));
    if (midi % 2 === 0) {
      const label = el("text", { x: 12, y: y + 4, fill: inScale ? "rgba(124,255,201,0.8)" : "rgba(169,165,184,0.58)", "font-size": 11, "font-weight": 700 });
      label.textContent = midiToNote(midi);
      svg.appendChild(label);
    }
  }
}

function renderTraceChart(data) {
  const svg = document.getElementById("trace-chart");
  svg.replaceChildren();
  const width = 1040, height = 430;
  const margin = { top: 22, right: 24, bottom: 88, left: 56 };
  const frames = data.trace;
  const pitchFrames = frames.filter(pitchDrawable);
  const scales = chartScales(frames, width, height - 58, margin);
  const enabledNotes = data.pitch_compass.notes.filter(note => note.enabled).map(note => note.name);

  svg.appendChild(el("rect", { x: 0, y: 0, width, height, rx: 20, fill: "rgba(0,0,0,0.16)" }));
  drawGrid(svg, scales, width, height - 58, margin, enabledNotes);

  const frameWidth = scales.innerWidth / frames.length;
  frames.forEach(frame => {
    if (guarded(frame)) {
      svg.appendChild(el("rect", { x: scales.x(frame) - frameWidth / 2, y: margin.top, width: Math.max(1.5, frameWidth), height: scales.innerHeight, fill: "rgba(255,184,77,0.12)" }));
    }
  });

  pitchFrames.filter((_, index) => index % 4 === 0).forEach(frame => {
    const x = scales.x(frame);
    svg.appendChild(el("line", {
      x1: x, y1: scales.yValue(frame.source_midi), x2: x, y2: scales.yValue(correctedMidi(frame)),
      stroke: guarded(frame) ? "rgba(255,184,77,0.45)" : "rgba(66,245,212,0.33)",
      "stroke-width": clamp(Math.abs(frame.correction_cents) / 18, 0.7, 3.5),
      "stroke-linecap": "round"
    }));
  });

  svg.appendChild(el("path", { d: pathFrom(pitchFrames, scales.x, f => scales.yValue(f.target_midi)), fill: "none", stroke: "rgba(183,140,255,0.82)", "stroke-width": 2.2, "stroke-dasharray": "8 8" }));
  svg.appendChild(el("path", { d: pathFrom(pitchFrames, scales.x, f => scales.yValue(f.source_midi)), fill: "none", stroke: "rgba(248,244,255,0.9)", "stroke-width": 2.4, "stroke-linejoin": "round" }));
  svg.appendChild(el("path", { d: pathFrom(pitchFrames, scales.x, f => scales.yValue(correctedMidi(f))), fill: "none", stroke: styleMeta[selectedStyle].color, "stroke-width": 3.5, "stroke-linejoin": "round", filter: "drop-shadow(0 0 7px rgba(66,245,212,0.45))" }));

  const confTop = 356;
  const protectTop = 316;
  svg.appendChild(el("text", { x: margin.left, y: protectTop - 10, fill: "rgba(169,165,184,0.85)", "font-size": 12, "font-weight": 800 }));
  svg.lastChild.textContent = "Guardrail lane: voiced / consonant / breath / silence protection";
  svg.appendChild(el("rect", { x: margin.left, y: protectTop, width: scales.innerWidth, height: 18, rx: 9, fill: "rgba(255,255,255,0.045)", stroke: "rgba(255,255,255,0.07)" }));
  frames.forEach(frame => {
    svg.appendChild(el("rect", {
      x: scales.x(frame) - frameWidth / 2,
      y: protectTop + 2,
      width: Math.max(1.5, frameWidth),
      height: 14,
      rx: 3,
      fill: protectedFrame(frame) ? segmentColor(frame) : "rgba(79,243,141,0.22)"
    }));
  });
  svg.appendChild(el("text", { x: margin.left, y: confTop - 12, fill: "rgba(169,165,184,0.85)", "font-size": 12, "font-weight": 800 }));
  svg.lastChild.textContent = "Confidence / Do No Harm threshold";
  svg.appendChild(el("rect", { x: margin.left, y: confTop, width: scales.innerWidth, height: 44, rx: 12, fill: "url(#confidenceGradient)" }));

  const defs = el("defs");
  const grad = el("linearGradient", { id: "confidenceGradient", x1: "0%", x2: "100%" });
  grad.appendChild(el("stop", { offset: "0%", "stop-color": "rgba(255,91,115,0.22)" }));
  grad.appendChild(el("stop", { offset: "48%", "stop-color": "rgba(255,184,77,0.2)" }));
  grad.appendChild(el("stop", { offset: "100%", "stop-color": "rgba(79,243,141,0.18)" }));
  defs.appendChild(grad);
  svg.prepend(defs);

  const yConf = frame => confTop + 38 - clamp(frame.confidence, 0, 1) * 36;
  svg.appendChild(el("path", { d: pathFrom(frames, scales.x, yConf), fill: "none", stroke: "rgba(255,255,255,0.82)", "stroke-width": 2 }));
  frames.filter(guarded).forEach(frame => {
    svg.appendChild(el("circle", { cx: scales.x(frame), cy: yConf(frame), r: 3.2, fill: "#ffb84d" }));
  });

  const calloutFrame = (pitchFrames.length ? pitchFrames : frames).reduce((worst, frame) => frame.confidence < worst.confidence ? frame : worst, (pitchFrames[0] || frames[0]));
  if (!pitchDrawable(calloutFrame)) return;
  const cx = scales.x(calloutFrame), cy = scales.yValue(calloutFrame.source_midi);
  svg.appendChild(el("circle", { cx, cy, r: 8, fill: "none", stroke: "#ffb84d", "stroke-width": 2.2 }));
  const labelBg = el("rect", { x: clamp(cx + 10, 70, 760), y: clamp(cy - 48, 24, 280), width: 246, height: 54, rx: 12, fill: "rgba(8,9,17,0.82)", stroke: "rgba(255,184,77,0.38)" });
  svg.appendChild(labelBg);
  const label1 = el("text", { x: Number(labelBg.getAttribute("x")) + 14, y: Number(labelBg.getAttribute("y")) + 22, fill: "#ffdaa3", "font-size": 12, "font-weight": 900 });
  label1.textContent = "Do No Harm fades correction";
  svg.appendChild(label1);
  const label2 = el("text", { x: Number(labelBg.getAttribute("x")) + 14, y: Number(labelBg.getAttribute("y")) + 40, fill: "#a9a5b8", "font-size": 11 });
  label2.textContent = `${midiToNote(calloutFrame.source_midi)} → ${calloutFrame.target_note}, confidence ${Math.round(calloutFrame.confidence * 100)}%`;
  svg.appendChild(label2);
}

function renderComparisonChart() {
  const svg = document.getElementById("comparison-chart");
  svg.replaceChildren();
  const width = 1040, height = 300;
  const margin = { top: 24, right: 24, bottom: 38, left: 56 };
  const frames = traces.natural.trace;
  const naturalPitchFrames = frames.filter(pitchDrawable);
  const scales = chartScales(frames, width, height, margin);
  const enabledNotes = traces[selectedStyle].pitch_compass.notes.filter(note => note.enabled).map(note => note.name);

  svg.appendChild(el("rect", { x: 0, y: 0, width, height, rx: 20, fill: "rgba(0,0,0,0.14)" }));
  drawGrid(svg, scales, width, height, margin, enabledNotes);

  svg.appendChild(el("path", { d: pathFrom(naturalPitchFrames, scales.x, f => scales.yValue(f.source_midi)), fill: "none", stroke: "rgba(248,244,255,0.45)", "stroke-width": 2.2 }));
  svg.appendChild(el("path", { d: pathFrom(naturalPitchFrames, scales.x, f => scales.yValue(f.target_midi)), fill: "none", stroke: "rgba(183,140,255,0.48)", "stroke-width": 1.9, "stroke-dasharray": "7 7" }));
  order.forEach(style => {
    const data = traces[style];
    svg.appendChild(el("path", {
      d: pathFrom(data.trace.filter(pitchDrawable), scales.x, f => scales.yValue(correctedMidi(f))),
      fill: "none",
      stroke: styleMeta[style].color,
      "stroke-width": style === selectedStyle ? 4 : 2.5,
      opacity: style === selectedStyle ? 1 : 0.58,
      "stroke-linejoin": "round"
    }));
  });

  order.forEach((style, index) => {
    const x = width - 210;
    const y = 32 + index * 26;
    svg.appendChild(el("line", { x1: x, y1: y, x2: x + 34, y2: y, stroke: styleMeta[style].color, "stroke-width": style === selectedStyle ? 5 : 3, "stroke-linecap": "round" }));
    const text = el("text", { x: x + 44, y: y + 4, fill: style === selectedStyle ? "#f8f4ff" : "#a9a5b8", "font-size": 13, "font-weight": style === selectedStyle ? 900 : 750 });
    text.textContent = styleMeta[style].title;
    svg.appendChild(text);
  });
}

function renderStyleCards() {
  const wrap = document.getElementById("style-cards");
  wrap.innerHTML = order.map(style => {
    const data = traces[style];
    const meta = styleMeta[style];
    const active = style === selectedStyle ? " active" : "";
    return `<article class="style-card${active}" data-style="${style}">
      <div class="style-swatch" style="background:${meta.color}"></div>
      <h3>${htmlEscape(meta.title)}</h3>
      <p>${htmlEscape(data.summary.avg_abs_correction_cents.toFixed(1))}¢ avg pull · ${data.summary.do_no_harm_events} guarded · ${data.summary.protected_region_count || 0} protected · ${data.summary.adaptive_events} adaptive</p>
    </article>`;
  }).join("");
  wrap.querySelectorAll(".style-card").forEach(card => card.addEventListener("click", () => {
    selectedStyle = card.dataset.style;
    render();
  }));
}

document.querySelectorAll(".style-button").forEach(button => button.addEventListener("click", () => {
  selectedStyle = button.dataset.style;
  render();
}));

render();
