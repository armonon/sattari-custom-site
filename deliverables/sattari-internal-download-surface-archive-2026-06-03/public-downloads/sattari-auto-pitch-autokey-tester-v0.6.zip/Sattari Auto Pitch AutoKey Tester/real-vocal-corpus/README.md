# Auto Pitch Real-Vocal Corpus

Internal-only corpus template for moving Auto Pitch from synthetic demos toward real-vocal evaluation readiness.

## Hard rule

Use only audio that is owned, cleared, public-domain, or generated as a synthetic fixture for internal evaluation. Do not add copyrighted/uncleared vocals. Do not publish these clips or renders. This folder is not a sale-ready product package.

## Manifest fields

Each `clips[]` entry must include:

- `clip_id` — stable short ID used in output filenames.
- `source_path` — path to a 16-bit PCM WAV, relative to the manifest file. For tests only, `__synthetic_generated_demo__` creates a local generated fixture.
- `permission_status` — one of `owned`, `cleared`, `public-domain`, or `synthetic-fixture`.
- `cleared_for_internal_eval` — must be `true` before batch evaluation runs.
- `public_release_allowed` — usually `false`; synthetic fixtures must stay false.
- `voice_range` — e.g. `alto`, `tenor`, `baritone`, or a short description.
- `expected_key` — `"auto"`, `"A minor"`, or `{ "root": "A", "scale": "minor" }`.
- `style_target` — one style, comma-separated styles, list of styles, or `all` (`natural`, `modern`, `hard`).
- `render_engines` — optional clip override; defaults to manifest engines (`psola-lite`, `granular`).
- `known_challenges` — list such as `sibilance`, `breath`, `wide vibrato`, `fast bends`.
- `notes` — rights/source/testing notes.

## Batch evaluation

From `prototypes/auto-pitch`:

```bash
python3 pitch_logic.py batch-evaluate \
  --manifest real-vocal-corpus/manifest.json \
  --out-dir out/corpus-eval
```

Expected output:

- `out/corpus-eval/traces/*-trace.json`
- `out/corpus-eval/guides/*-guide.wav`
- `out/corpus-eval/wavs/*-{psola-lite,granular}.wav`
- `out/corpus-eval/metrics/*-metrics.json`
- `out/corpus-eval/listening-review.csv`
- `out/corpus-eval/listening-review.md`
- `out/corpus-eval/batch-summary.json`

The CSV/Markdown review sheets are intentionally blank score forms. A human still has to listen in a DAW/headphones and score pitch correctness, timbre, consonants, breath/silence preservation, protected-region artifacts, vibrato/bends, artifact severity, and usability. Batch metrics also include `segment_counts`, `protection_flag_counts`, `protected_region_count`, and `artifact_review_required` so review can focus on likely artifact zones.

## Synthetic smoke fixture

`manifest.synthetic-fixture.json` runs without real vocals and generates a local synthetic WAV fixture. It is only a pipeline smoke test; it does not count as real-vocal evidence.

```bash
python3 pitch_logic.py batch-evaluate \
  --manifest real-vocal-corpus/manifest.synthetic-fixture.json \
  --out-dir out/corpus-eval-smoke
```
