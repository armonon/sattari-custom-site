#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m unittest -v test_pitch_logic.py
python3 pitch_logic.py --demo --out-dir out
python3 pitch_logic.py --demo --adapt --style modern --out-dir out
open out
open ui/index.html
