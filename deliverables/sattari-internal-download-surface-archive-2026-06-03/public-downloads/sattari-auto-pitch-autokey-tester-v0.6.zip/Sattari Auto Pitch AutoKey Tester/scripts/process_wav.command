#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ $# -lt 1 ]]; then
  osascript -e 'display dialog "Drag a 16-bit PCM vocal WAV onto this command file to process it." buttons {"OK"} default button "OK"'
  exit 1
fi
input="$1"
base="$(basename "$input" .wav)"
mkdir -p out
python3 pitch_logic.py \
  --input-wav "$input" \
  --auto-key \
  --style modern \
  --out "out/${base}-modern-trace.json" \
  --render-guide-wav "out/${base}-modern-guide.wav" \
  --render-corrected-wav "out/${base}-modern-corrected.wav" \
  --render-engine psola-lite \
  --render-metrics "out/${base}-modern-render-metrics.json"
open out
