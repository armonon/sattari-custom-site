#!/usr/bin/env python3
"""Auto Pitch v0 offline prototype harness.

This intentionally stays dependency-light (Python standard library only) so the
prototype can run tonight on a fresh machine. It does three useful things:

1. Generates a vocal-like monophonic demo WAV with scoops, vibrato, jumps, and
   ambiguous/low-energy regions.
2. Detects a pitch contour from a mono WAV using a simple autocorrelation YIN-ish
   baseline with confidence scoring.
3. Quantizes/corrects the contour toward a key/scale with style presets,
   adaptive phrase behavior, and confidence-driven Do No Harm guardrails.

The default audio render is a *pitch guide resynthesis* (harmonic oscillator
following corrected pitch), not a production vocal pitch shifter. v0.4 also
includes an experimental dependency-free granular/time-domain corrected-audio
renderer that uses the original WAV samples instead of an oscillator. It is
useful for local testing and directionally proving the correction path, but it
is still not PSOLA/phase-vocoder/Rubber Band quality.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11],
    "minor": [0, 2, 3, 5, 7, 8, 10],
    "chromatic": list(range(12)),
}
STYLE_PRESETS = {
    "natural": {
        "label": "Natural Pop",
        "amount": 0.52,
        "speed": 0.34,
        "confidence_floor": 0.48,
        "bend_preserve": 0.72,
        "vibrato_preserve": 0.72,
        "max_cents_per_frame": 18.0,
    },
    "modern": {
        "label": "Modern Tight",
        "amount": 0.82,
        "speed": 0.70,
        "confidence_floor": 0.36,
        "bend_preserve": 0.46,
        "vibrato_preserve": 0.38,
        "max_cents_per_frame": 42.0,
    },
    "hard": {
        "label": "Hard Tune",
        "amount": 1.0,
        "speed": 0.96,
        "confidence_floor": 0.24,
        "bend_preserve": 0.10,
        "vibrato_preserve": 0.08,
        "max_cents_per_frame": 120.0,
    },
}
STYLE_ALIASES = {
    "natural-pop": "natural",
    "modern-tight": "modern",
    "tight": "modern",
    "hard-tune": "hard",
}
DEFAULT_SAMPLE_RATE = 44_100
MANIFEST_REQUIRED_CLIP_FIELDS = [
    "clip_id",
    "source_path",
    "permission_status",
    "cleared_for_internal_eval",
    "voice_range",
    "expected_key",
    "style_target",
    "known_challenges",
    "notes",
]
ALLOWED_PERMISSION_STATUSES = {"owned", "cleared", "public-domain", "synthetic-fixture"}
LISTENING_REVIEW_COLUMNS = [
    "clip_id",
    "voice_range",
    "source_path",
    "expected_key",
    "style",
    "render_engine",
    "trace_path",
    "guide_wav_path",
    "corrected_wav_path",
    "metrics_path",
    "segment_mix",
    "protected_region_count",
    "protection_flags",
    "artifact_review_required",
    "pitch_correctness_1_5",
    "naturalness_timbre_1_5",
    "consonants_1_5",
    "breath_silence_preservation_1_5",
    "protected_region_artifacts_1_5",
    "vibrato_bend_1_5",
    "artifact_severity_1_5",
    "daw_usability_1_5",
    "best_style",
    "timestamp_notes",
    "artifact_review_notes",
    "reviewer",
    "review_date",
]


@dataclass
class PitchPoint:
    time: float
    hz: float
    confidence: float = 1.0
    rms: float = 1.0


def hz_to_midi(hz: float) -> float:
    if hz <= 0:
        raise ValueError("Hz must be positive")
    return 69.0 + 12.0 * math.log2(hz / 440.0)


def midi_to_hz(midi: float) -> float:
    return 440.0 * (2.0 ** ((midi - 69.0) / 12.0))


def note_name(midi: float) -> str:
    rounded = int(round(midi))
    return f"{NOTE_NAMES[rounded % 12]}{rounded // 12 - 1}"


def parse_root(root: str) -> int:
    normalized = root.strip().upper().replace("♯", "#").replace("♭", "B")
    flats = {"DB": "C#", "EB": "D#", "GB": "F#", "AB": "G#", "BB": "A#"}
    normalized = flats.get(normalized, normalized)
    if normalized not in NOTE_NAMES:
        raise ValueError(f"Unsupported root note: {root}")
    return NOTE_NAMES.index(normalized)


def allowed_pitch_classes(root: str, scale: str) -> set[int]:
    if scale not in SCALES:
        raise ValueError(f"Unsupported scale: {scale}. Try {', '.join(SCALES)}")
    root_pc = parse_root(root)
    return {(root_pc + interval) % 12 for interval in SCALES[scale]}


def nearest_allowed_midi(midi: float, allowed_pcs: set[int]) -> int:
    base = int(round(midi))
    candidates = [n for n in range(base - 12, base + 13) if n % 12 in allowed_pcs]
    return min(candidates, key=lambda n: abs(n - midi))


def cents_between(a_midi: float, b_midi: float) -> float:
    return (b_midi - a_midi) * 100.0


def normalize_style(style: str) -> str:
    key = style.strip().lower().replace("_", "-").replace(" ", "-")
    key = STYLE_ALIASES.get(key, key)
    if key not in STYLE_PRESETS:
        raise ValueError(f"Unsupported style: {style}. Try {', '.join(STYLE_PRESETS)}")
    return key


def correction_strength(confidence: float, amount: float, confidence_floor: float) -> float:
    """Confidence-driven Do No Harm behavior.

    Below the confidence floor, correction fades down instead of snapping.
    """

    if confidence <= 0:
        return 0.0
    if confidence >= confidence_floor:
        return amount
    return amount * max(0.0, confidence / confidence_floor)


def adaptive_strength(
    *,
    base_strength: float,
    source_midi: float,
    previous_source_midi: float | None,
    preset: dict,
) -> tuple[float, list[str]]:
    """Reduce correction during expressive movement.

    v0 heuristic: if the source moves quickly between frames, treat it as a
    scoop/fall/transition and preserve more of the gesture. Small alternating
    motion is treated as possible vibrato and also softened for natural styles.
    """

    flags: list[str] = []
    if previous_source_midi is None:
        return base_strength, flags

    delta_cents = abs(cents_between(previous_source_midi, source_midi))
    strength = base_strength
    if delta_cents > 190:
        strength *= 1.0 - preset["bend_preserve"]
        flags.append("bend_or_note_transition_preserved")
    elif 28 <= delta_cents <= 90:
        strength *= 1.0 - preset["vibrato_preserve"] * 0.45
        flags.append("possible_vibrato_preserved")
    return max(0.0, min(1.0, strength)), flags


def smooth_output(
    *,
    desired_midi: float,
    source_midi: float,
    target_midi: int,
    previous_out_midi: float | None,
    previous_source_midi: float | None,
    speed: float,
    max_cents_per_frame: float,
) -> tuple[float, str | None]:
    if previous_out_midi is None or previous_source_midi is None:
        return desired_midi, "phrase_start"

    source_jump = abs(cents_between(previous_source_midi, source_midi))
    target_distance = abs(cents_between(source_midi, target_midi))
    output_lag = abs(cents_between(source_midi, previous_out_midi))

    # Important bugfix vs Phase 0: do not glide from A3 to E4 just because the
    # previous output was A3. A new source note/fast movement should track the
    # singer first, then correct; otherwise natural mode creates fake portamento.
    if source_jump > 110 or target_distance > 180 or output_lag > 160:
        return desired_midi, "phrase_reset"

    stepped = previous_out_midi + (desired_midi - previous_out_midi) * speed
    max_step = max_cents_per_frame / 100.0
    delta = stepped - previous_out_midi
    if abs(delta) > max_step:
        stepped = previous_out_midi + math.copysign(max_step, delta)
        return stepped, "slew_limited"
    return stepped, None


def summarize_trace(rows: Sequence[dict]) -> dict:
    voiced = [r for r in rows if r.get("source_hz", 0) > 0]
    segment_counts: dict[str, int] = {}
    protection_counts: dict[str, int] = {}
    protected_rows = 0
    for row in rows:
        segment = str(row.get("segment_label") or "unknown")
        segment_counts[segment] = segment_counts.get(segment, 0) + 1
        flags = [str(flag) for flag in row.get("protection_flags", [])]
        if flags:
            protected_rows += 1
        for flag in flags:
            protection_counts[flag] = protection_counts.get(flag, 0) + 1
    if not voiced:
        return {
            "points": len(rows),
            "voiced_points": 0,
            "voiced_ratio": 0.0,
            "segment_counts": segment_counts,
            "protected_region_count": protected_rows,
            "protection_flag_counts": protection_counts,
        }
    corrections = [abs(float(r["correction_cents"])) for r in voiced]
    confs = [float(r["confidence"]) for r in voiced]
    return {
        "points": len(rows),
        "voiced_points": len(voiced),
        "voiced_ratio": round(len(voiced) / max(1, len(rows)), 3),
        "segment_counts": segment_counts,
        "protected_region_count": protected_rows,
        "protection_flag_counts": protection_counts,
        "avg_confidence": round(sum(confs) / len(confs), 3),
        "avg_abs_correction_cents": round(sum(corrections) / len(corrections), 2),
        "max_abs_correction_cents": round(max(corrections), 2),
        "do_no_harm_events": sum(
            1
            for r in voiced
            if any(str(flag).startswith("low_confidence") for flag in r.get("guardrails", []))
        ),
        "phrase_resets": sum(1 for r in voiced if r.get("phrase_event") == "phrase_reset"),
        "adaptive_events": sum(1 for r in voiced if r.get("adaptive_flags")),
    }


def classify_segment(point: PitchPoint, previous_point: PitchPoint | None, next_point: PitchPoint | None) -> str:
    """Classify a trace frame for conservative vocal protection.

    This is intentionally dependency-free v0 segmentation. It uses the existing
    detector output (pitch, confidence, RMS) plus neighbor context to identify
    frames that should not be pitch-shifted aggressively: consonant/transient,
    breath, silence, and generic unvoiced regions.
    """

    rms = max(0.0, float(point.rms))
    confidence = max(0.0, float(point.confidence))
    pitched = point.hz > 0.0 and confidence >= 0.16 and rms >= 0.018
    neighbor_voiced = any(
        neighbor is not None and neighbor.hz > 0.0 and neighbor.confidence >= 0.20 and neighbor.rms >= 0.018
        for neighbor in (previous_point, next_point)
    )

    if rms < 0.012 or (point.hz <= 0.0 and confidence <= 0.03 and rms < 0.028):
        return "silence"
    if pitched and confidence >= 0.30:
        return "voiced"
    if rms >= 0.115 or (neighbor_voiced and rms >= 0.055 and confidence < 0.24):
        return "consonant"
    if rms >= 0.020 and confidence < 0.20:
        return "breath"
    if pitched:
        return "voiced_low_confidence"
    return "unvoiced"


def protection_flags_for_segment(segment: str, confidence: float, confidence_floor: float) -> list[str]:
    flags: list[str] = []
    if segment in {"silence", "breath", "consonant", "unvoiced"}:
        flags.append("copy_source")
        flags.append(f"protect_{segment}")
    elif segment == "voiced_low_confidence":
        flags.append("backoff_low_confidence_voiced")
    elif confidence < confidence_floor:
        flags.append("backoff_low_confidence")
    return flags


def row_is_copy_protected(row: dict) -> bool:
    flags = {str(flag) for flag in row.get("protection_flags", [])}
    return "copy_source" in flags or str(row.get("render_action") or "") == "copy_source"


def trace_protection_summary(trace: Sequence[dict]) -> dict:
    segment_counts: dict[str, int] = {}
    protection_flag_counts: dict[str, int] = {}
    for row in trace:
        segment = str(row.get("segment_label") or "unknown")
        segment_counts[segment] = segment_counts.get(segment, 0) + 1
        for flag in row.get("protection_flags", []):
            flag = str(flag)
            protection_flag_counts[flag] = protection_flag_counts.get(flag, 0) + 1
    protected_rows = sum(1 for row in trace if row.get("protection_flags"))
    return {
        "segment_counts": segment_counts,
        "protected_region_count": protected_rows,
        "protection_flag_counts": protection_flag_counts,
        "artifact_review_required": protected_rows > 0,
    }


def pitch_class_histogram(points: Iterable[PitchPoint]) -> dict[str, float]:
    weights = {name: 0.0 for name in NOTE_NAMES}
    total = 0.0
    for p in points:
        if p.hz <= 0 or p.confidence <= 0:
            continue
        midi = hz_to_midi(p.hz)
        pc = int(round(midi)) % 12
        # Weight confident, centered notes more than ambiguous in-between frames.
        detune = abs(cents_between(midi, round(midi)))
        centered = max(0.05, 1.0 - min(detune, 50.0) / 50.0)
        weight = p.confidence * centered
        weights[NOTE_NAMES[pc]] += weight
        total += weight
    if total > 0:
        return {k: round(v / total, 4) for k, v in weights.items()}
    return weights


def estimate_key(points: Sequence[PitchPoint], top_n: int = 5) -> dict:
    candidates: list[tuple[float, str, str]] = []
    voiced = [p for p in points if p.hz > 0 and p.confidence > 0.05]
    if not voiced:
        return {"root": "C", "scale": "chromatic", "confidence": 0.0, "alternatives": []}

    for root in NOTE_NAMES:
        for scale in ("major", "minor"):
            allowed = allowed_pitch_classes(root, scale)
            score = 0.0
            possible = 0.0
            for p in voiced:
                midi = hz_to_midi(p.hz)
                target = nearest_allowed_midi(midi, allowed)
                distance = abs(cents_between(midi, target))
                closeness = max(0.0, 1.0 - min(distance, 100.0) / 100.0)
                weight = p.confidence * max(0.2, p.rms)
                score += closeness * weight
                possible += weight
            candidates.append((score / max(1e-9, possible), root, scale))

    candidates.sort(reverse=True, key=lambda t: t[0])
    best = candidates[0]
    second = candidates[1][0] if len(candidates) > 1 else 0.0
    # Confidence is score quality plus margin over runner-up.
    confidence = max(0.0, min(1.0, best[0] * 0.72 + (best[0] - second) * 0.9))
    return {
        "root": best[1],
        "scale": best[2],
        "confidence": round(confidence, 3),
        "alternatives": [
            {"root": r, "scale": s, "score": round(score, 3)}
            for score, r, s in candidates[:top_n]
        ],
    }


def pitch_compass(points: Sequence[PitchPoint], root: str, scale: str) -> dict:
    allowed = allowed_pitch_classes(root, scale)
    hist = pitch_class_histogram(points)
    notes = []
    for pc, name in enumerate(NOTE_NAMES):
        notes.append(
            {
                "name": name,
                "enabled": pc in allowed,
                "histogram_weight": hist[name],
                "gravity": round(1.0 if pc in allowed else 0.0, 3),
            }
        )
    return {"root": root, "scale": scale, "notes": notes}


def correct_contour(
    points: Iterable[PitchPoint],
    *,
    root: str,
    scale: str,
    style: str,
) -> list[dict]:
    point_list = list(points)
    style = normalize_style(style)
    preset = STYLE_PRESETS[style]
    allowed = allowed_pitch_classes(root, scale)
    rows: list[dict] = []
    previous_out_midi: float | None = None
    previous_source_midi: float | None = None

    for idx, p in enumerate(point_list):
        previous_point = point_list[idx - 1] if idx > 0 else None
        next_point = point_list[idx + 1] if idx + 1 < len(point_list) else None
        segment_label = classify_segment(p, previous_point, next_point)
        segment_protection = protection_flags_for_segment(segment_label, p.confidence, preset["confidence_floor"])
        render_action = "copy_source" if "copy_source" in segment_protection else "pitch_shift"
        if p.hz <= 0:
            rows.append(
                {
                    "time": round(p.time, 4),
                    "source_hz": 0.0,
                    "source_note": None,
                    "confidence": round(p.confidence, 3),
                    "rms": round(p.rms, 4),
                    "segment_label": segment_label,
                    "protection_flags": segment_protection,
                    "render_action": render_action,
                    "target_note": None,
                    "target_hz": 0.0,
                    "corrected_hz": 0.0,
                    "correction_cents": 0.0,
                    "do_no_harm_strength": 0.0,
                    "adaptive_strength": 0.0,
                    "guardrails": ["unvoiced_bypass", *segment_protection],
                    "adaptive_flags": [],
                    "phrase_event": None,
                }
            )
            previous_out_midi = None
            previous_source_midi = None
            continue

        source_midi = hz_to_midi(p.hz)
        target_midi = nearest_allowed_midi(source_midi, allowed)
        base_strength = correction_strength(p.confidence, preset["amount"], preset["confidence_floor"])
        strength, adaptive_flags = adaptive_strength(
            base_strength=base_strength,
            source_midi=source_midi,
            previous_source_midi=previous_source_midi,
            preset=preset,
        )
        desired_midi = source_midi + (target_midi - source_midi) * strength
        out_midi, phrase_event = smooth_output(
            desired_midi=desired_midi,
            source_midi=source_midi,
            target_midi=target_midi,
            previous_out_midi=previous_out_midi,
            previous_source_midi=previous_source_midi,
            speed=preset["speed"],
            max_cents_per_frame=preset["max_cents_per_frame"],
        )
        previous_out_midi = out_midi
        previous_source_midi = source_midi

        guardrails = []
        if p.confidence < preset["confidence_floor"]:
            guardrails.append("low_confidence_do_no_harm")
        if abs(cents_between(source_midi, target_midi)) > 125:
            guardrails.append("large_pitch_error_watch")
        for flag in segment_protection:
            if flag not in guardrails:
                guardrails.append(flag)

        rows.append(
            {
                "time": round(p.time, 4),
                "source_hz": round(p.hz, 4),
                "source_note": note_name(source_midi),
                "source_midi": round(source_midi, 4),
                "confidence": round(p.confidence, 3),
                "rms": round(p.rms, 4),
                "segment_label": segment_label,
                "protection_flags": segment_protection,
                "render_action": render_action,
                "target_note": note_name(target_midi),
                "target_midi": target_midi,
                "target_hz": round(midi_to_hz(target_midi), 4),
                "corrected_hz": round(midi_to_hz(out_midi), 4),
                "corrected_note": note_name(out_midi),
                "correction_cents": round(cents_between(source_midi, out_midi), 2),
                "target_error_cents": round(cents_between(source_midi, target_midi), 2),
                "do_no_harm_strength": round(base_strength, 3),
                "adaptive_strength": round(strength, 3),
                "guardrails": guardrails,
                "adaptive_flags": adaptive_flags,
                "phrase_event": phrase_event,
            }
        )
    return rows


def contour_end_time(points: Sequence[PitchPoint]) -> float:
    if not points:
        return 0.0
    if len(points) == 1:
        return points[0].time
    hops = [b.time - a.time for a, b in zip(points, points[1:]) if b.time > a.time]
    hop = statistics.median(hops) if hops else 0.02
    return points[-1].time + hop


def same_key(a: dict, b: dict) -> bool:
    return a.get("root") == b.get("root") and a.get("scale") == b.get("scale")


def relative_key_ambiguous(alternatives: Sequence[dict], root: str, scale: str, *, score_margin: float = 0.035) -> bool:
    if not alternatives:
        return False
    top_score = float(alternatives[0].get("score", 0.0))
    signature = allowed_pitch_classes(root, scale)
    for alt in alternatives[1:4]:
        alt_score = float(alt.get("score", 0.0))
        if top_score - alt_score > score_margin:
            continue
        try:
            if allowed_pitch_classes(str(alt["root"]), str(alt["scale"])) == signature:
                return True
        except (KeyError, ValueError):
            continue
    return False


def estimate_adapt_key_map(
    points: Sequence[PitchPoint],
    *,
    window_seconds: float = 1.0,
    min_section_seconds: float = 0.9,
    confidence_floor: float = 0.42,
) -> dict:
    """Estimate a conservative offline key-zone timeline.

    v0 Adapt Mode is intentionally simple: non-overlapping windows, key scoring,
    isolated-flip suppression, then adjacent merge. The goal is not perfect music
    theory yet; it is a stable section map that avoids frame-by-frame key jitter.
    """

    ordered = sorted(points, key=lambda p: p.time)
    if not ordered:
        return {
            "version": "adapt-v0.1",
            "mode": "offline_adapt",
            "window_seconds": window_seconds,
            "min_section_seconds": min_section_seconds,
            "sections": [],
            "warnings": ["no_pitch_points"],
        }

    total_end = contour_end_time(ordered)
    raw: list[dict] = []
    start = ordered[0].time
    window_index = 0
    while start < total_end - 1e-9:
        end = min(total_end, start + window_seconds)
        window_points = [p for p in ordered if start <= p.time < end]
        voiced = [p for p in window_points if p.hz > 0 and p.confidence > 0.05]
        warnings: list[str] = []
        if len(voiced) < 4:
            suggestion = {"root": "C", "scale": "chromatic", "confidence": 0.0, "alternatives": []}
            warnings.append("insufficient_voiced_pitch_for_key_estimate")
        else:
            suggestion = estimate_key(voiced, top_n=5)
            if suggestion["confidence"] < confidence_floor:
                warnings.append("low_confidence_key_estimate")
            if relative_key_ambiguous(suggestion.get("alternatives", []), suggestion["root"], suggestion["scale"]):
                warnings.append("relative_major_minor_ambiguous")
        raw.append(
            {
                "section_id": f"raw_{window_index:03d}",
                "start": round(start, 4),
                "end": round(end, 4),
                "root": suggestion["root"],
                "scale": suggestion["scale"],
                "confidence": float(suggestion["confidence"]),
                "alternatives": suggestion.get("alternatives", []),
                "warnings": warnings,
                "voiced_points": len(voiced),
            }
        )
        start = end
        window_index += 1

    # Conservative smoothing: remove one-window key flips when the neighbors
    # agree. This prevents jitter from a single ambiguous phrase/window.
    smoothed = [dict(r) for r in raw]
    for i in range(1, len(smoothed) - 1):
        prev, cur, nxt = smoothed[i - 1], smoothed[i], smoothed[i + 1]
        if same_key(prev, nxt) and not same_key(prev, cur):
            cur_duration = float(cur["end"]) - float(cur["start"])
            if cur["confidence"] < 0.68 or cur_duration <= min_section_seconds * 1.25:
                cur["root"] = prev["root"]
                cur["scale"] = prev["scale"]
                cur["confidence"] = min(float(cur["confidence"]), float(prev["confidence"]))
                cur.setdefault("warnings", []).append("smoothed_isolated_key_flip")

    sections: list[dict] = []
    for item in smoothed:
        if sections and same_key(sections[-1], item):
            prev = sections[-1]
            prev["end"] = item["end"]
            prev["confidence_values"].append(float(item["confidence"]))
            prev["confidence"] = round(sum(prev["confidence_values"]) / len(prev["confidence_values"]), 3)
            prev["voiced_points"] += int(item.get("voiced_points", 0))
            for warning in item.get("warnings", []):
                if warning not in prev["warnings"]:
                    prev["warnings"].append(warning)
            # Keep a compact explanation trail; first alternatives are enough
            # for UI hover/detail in this prototype.
            if not prev["alternatives"] and item.get("alternatives"):
                prev["alternatives"] = item["alternatives"]
        else:
            section = dict(item)
            section["confidence_values"] = [float(section["confidence"])]
            section["confidence"] = round(float(section["confidence"]), 3)
            sections.append(section)

    # Merge very short low-confidence sections into the previous zone when safe.
    conservative: list[dict] = []
    for section in sections:
        duration = float(section["end"]) - float(section["start"])
        if conservative and duration < min_section_seconds and section["confidence"] < confidence_floor:
            prev = conservative[-1]
            prev["end"] = section["end"]
            prev["warnings"].append("absorbed_short_low_confidence_neighbor")
            continue
        conservative.append(section)

    final_sections: list[dict] = []
    for idx, section in enumerate(conservative):
        cleaned = {
            "section_id": f"adapt_{idx:03d}",
            "start": round(float(section["start"]), 4),
            "end": round(float(section["end"]), 4),
            "root": section["root"],
            "scale": section["scale"],
            "confidence": round(float(section["confidence"]), 3),
            "alternatives": section.get("alternatives", []),
            "warnings": section.get("warnings", []),
        }
        if cleaned["confidence"] < confidence_floor and "low_confidence_key_estimate" not in cleaned["warnings"]:
            cleaned["warnings"].append("low_confidence_key_estimate")
        final_sections.append(cleaned)

    global_warnings: list[str] = []
    if len(final_sections) <= 1:
        global_warnings.append("single_key_zone_detected")
    if any("relative_major_minor_ambiguous" in s["warnings"] for s in final_sections):
        global_warnings.append("some_sections_have_relative_major_minor_ambiguity")

    return {
        "version": "adapt-v0.1",
        "mode": "offline_adapt",
        "window_seconds": window_seconds,
        "min_section_seconds": min_section_seconds,
        "smoothing": "non_overlapping_windows_merge_adjacent_suppress_isolated_flips",
        "sections": final_sections,
        "warnings": global_warnings,
    }


def section_for_time(sections: Sequence[dict], time: float) -> dict:
    if not sections:
        return {
            "section_id": "adapt_none",
            "start": 0.0,
            "end": 0.0,
            "root": "C",
            "scale": "chromatic",
            "confidence": 0.0,
            "alternatives": [],
            "warnings": ["missing_adapt_section"],
        }
    for section in sections:
        if float(section["start"]) <= time < float(section["end"]):
            return section
    return sections[-1]


def correct_contour_adapt(points: Sequence[PitchPoint], *, adapt_key_map: dict, style: str) -> list[dict]:
    sections = adapt_key_map.get("sections", [])
    rows: list[dict] = []
    for section in sections:
        section_points = [p for p in points if float(section["start"]) <= p.time < float(section["end"])]
        section_rows = correct_contour(section_points, root=section["root"], scale=section["scale"], style=style)
        for row in section_rows:
            row.update(
                {
                    "adapt_section_id": section["section_id"],
                    "section_start": section["start"],
                    "section_end": section["end"],
                    "section_root": section["root"],
                    "section_scale": section["scale"],
                    "section_confidence": section["confidence"],
                    "section_warnings": section.get("warnings", []),
                }
            )
        rows.extend(section_rows)
    # Preserve any points that fell outside rounded section ranges.
    covered_times = {float(r["time"]) for r in rows}
    for p in points:
        if round(p.time, 4) in covered_times:
            continue
        section = section_for_time(sections, p.time)
        row = correct_contour([p], root=section["root"], scale=section["scale"], style=style)[0]
        row.update(
            {
                "adapt_section_id": section["section_id"],
                "section_start": section["start"],
                "section_end": section["end"],
                "section_root": section["root"],
                "section_scale": section["scale"],
                "section_confidence": section["confidence"],
                "section_warnings": section.get("warnings", []),
            }
        )
        rows.append(row)
    rows.sort(key=lambda r: float(r["time"]))
    return rows


def build_trace_document(points: Sequence[PitchPoint], *, root: str | None, scale: str | None, style: str, source: str) -> dict:
    suggestion = estimate_key(points)
    root = root or suggestion["root"]
    scale = scale or suggestion["scale"]
    style = normalize_style(style)
    trace = correct_contour(points, root=root, scale=scale, style=style)
    return {
        "version": "0.6.0-guardrail-segmentation-v0",
        "source": source,
        "settings": {
            "root": root,
            "scale": scale,
            "style": style,
            "style_label": STYLE_PRESETS[style]["label"],
        },
        "key_suggestion": suggestion,
        "pitch_compass": pitch_compass(points, root, scale),
        "summary": summarize_trace(trace),
        "trace": trace,
    }


def build_adapt_trace_document(
    points: Sequence[PitchPoint],
    *,
    style: str,
    source: str,
    window_seconds: float = 1.0,
    min_section_seconds: float = 0.9,
) -> dict:
    style = normalize_style(style)
    adapt_key_map = estimate_adapt_key_map(
        points,
        window_seconds=window_seconds,
        min_section_seconds=min_section_seconds,
    )
    trace = correct_contour_adapt(points, adapt_key_map=adapt_key_map, style=style)
    first_section = adapt_key_map["sections"][0] if adapt_key_map["sections"] else {"root": "C", "scale": "chromatic"}
    summary = summarize_trace(trace)
    summary.update(
        {
            "adapt_sections": len(adapt_key_map.get("sections", [])),
            "adapt_key_changes": max(0, len(adapt_key_map.get("sections", [])) - 1),
        }
    )
    return {
        "version": "0.6.0-adapt-guardrail-segmentation-v0",
        "source": source,
        "settings": {
            "adapt": True,
            "style": style,
            "style_label": STYLE_PRESETS[style]["label"],
        },
        "adapt_key_map": adapt_key_map,
        "pitch_compass": pitch_compass(points, first_section["root"], first_section["scale"]),
        "summary": summary,
        "trace": trace,
    }


def load_csv(path: Path) -> list[PitchPoint]:
    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        return [
            PitchPoint(
                time=float(row["time"]),
                hz=float(row["hz"]),
                confidence=float(row.get("confidence", 1.0)),
                rms=float(row.get("rms", 1.0)),
            )
            for row in reader
        ]


def generated_demo_contour(frame_hop: float = 0.02) -> list[PitchPoint]:
    """Vocal-like A minor phrase: scoop, hold/vibrato, leap, fall, ambiguity."""

    segments = [
        # duration, start hz, end hz, confidence, vibrato depth cents
        (0.24, 205.0, 220.0, 0.82, 6.0),   # scoop into A3
        (0.44, 221.5, 219.0, 0.90, 18.0),  # held A with vibrato
        (0.12, 245.0, 329.6, 0.52, 4.0),   # fast transition/leap
        (0.40, 333.0, 329.6, 0.88, 10.0),  # E4 slightly sharp
        (0.18, 300.0, 261.6, 0.40, 5.0),   # fall, ambiguous
        (0.36, 258.0, 261.6, 0.86, 12.0),  # C4 recovery
        (0.34, 397.0, 392.0, 0.88, 16.0),  # G4 hold
        (0.16, 392.0, 370.0, 0.22, 4.0),   # low-confidence bluesy fall
        (0.34, 440.0, 440.0, 0.90, 8.0),   # A4 close
    ]
    points: list[PitchPoint] = []
    t = 0.0
    for duration, start_hz, end_hz, conf, vib_cents in segments:
        steps = max(1, int(round(duration / frame_hop)))
        for i in range(steps):
            x = i / max(1, steps - 1)
            hz = start_hz + (end_hz - start_hz) * x
            vib = math.sin(2 * math.pi * 5.4 * t) * vib_cents / 100.0
            hz *= 2 ** (vib / 12.0)
            # Lower RMS on ambiguous/transition regions to simulate breath/noise.
            rms = 0.18 if conf < 0.55 else 0.9
            points.append(PitchPoint(time=round(t, 4), hz=hz, confidence=conf, rms=rms))
            t += frame_hop
    return points


def generated_adapt_demo_contour(frame_hop: float = 0.02) -> list[PitchPoint]:
    """Two-zone Adapt demo contour: C-major/A-minor family into E-major family.

    The first zone intentionally looks like a relative major/minor case so the
    key map can surface that warning. The second zone adds G#/C#/F# so Adapt has
    a clear new target set instead of one static scale for the whole song.
    """

    segments = [
        # duration, start hz, end hz, confidence, vibrato depth cents
        # Zone 1: C major / A minor pitch-class family.
        (0.32, 257.0, 261.6, 0.88, 9.0),   # C4 slight scoop
        (0.32, 292.0, 293.7, 0.86, 7.0),   # D4
        (0.36, 351.0, 349.2, 0.90, 10.0),  # F4
        (0.32, 389.0, 392.0, 0.88, 12.0),  # G4
        (0.34, 436.0, 440.0, 0.91, 8.0),   # A4
        (0.34, 332.0, 329.6, 0.86, 8.0),   # E4
        # Zone 2: E major / C# minor pitch-class family.
        (0.34, 326.0, 329.6, 0.88, 8.0),   # E4
        (0.34, 410.0, 415.3, 0.90, 9.0),   # G#4
        (0.32, 489.0, 493.9, 0.89, 7.0),   # B4
        (0.32, 548.0, 554.4, 0.86, 8.0),   # C#5
        (0.30, 373.0, 370.0, 0.84, 10.0),  # F#4
        (0.42, 332.0, 329.6, 0.89, 8.0),   # E4 close
    ]
    points: list[PitchPoint] = []
    t = 0.0
    for duration, start_hz, end_hz, conf, vib_cents in segments:
        steps = max(1, int(round(duration / frame_hop)))
        for i in range(steps):
            x = i / max(1, steps - 1)
            hz = start_hz + (end_hz - start_hz) * x
            vib = math.sin(2 * math.pi * 5.1 * t) * vib_cents / 100.0
            hz *= 2 ** (vib / 12.0)
            points.append(PitchPoint(time=round(t, 4), hz=hz, confidence=conf, rms=0.9))
            t += frame_hop
    return points


def read_wav_mono(path: Path) -> tuple[int, list[float]]:
    with wave.open(str(path), "rb") as wf:
        channels = wf.getnchannels()
        sample_width = wf.getsampwidth()
        sample_rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())
    if sample_width != 2:
        raise ValueError("Only 16-bit PCM WAV is supported in the stdlib prototype")

    samples: list[float] = []
    step = sample_width * channels
    for i in range(0, len(frames), step):
        acc = 0.0
        for ch in range(channels):
            j = i + ch * sample_width
            val = int.from_bytes(frames[j : j + 2], byteorder="little", signed=True)
            acc += val / 32768.0
        samples.append(acc / channels)
    return sample_rate, samples


def write_wav_mono(path: Path, sample_rate: int, samples: Sequence[float]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        data = bytearray()
        for s in samples:
            clipped = max(-1.0, min(1.0, float(s)))
            data.extend(int(round(clipped * 32767.0)).to_bytes(2, byteorder="little", signed=True))
        wf.writeframes(bytes(data))


def contour_to_samples(points: Sequence[PitchPoint], sample_rate: int = DEFAULT_SAMPLE_RATE, harmonics: bool = True) -> list[float]:
    if not points:
        return []
    hop = points[1].time - points[0].time if len(points) > 1 else 0.02
    total_samples = int((points[-1].time + hop) * sample_rate)
    samples: list[float] = []
    phase = 0.0
    for n in range(total_samples):
        t = n / sample_rate
        idx = min(len(points) - 1, int(t / hop))
        p = points[idx]
        hz = max(20.0, p.hz)
        phase += 2 * math.pi * hz / sample_rate
        # Vocal-ish harmonic stack, enough for pitch detector and audible guide.
        amp = 0.28 * max(0.05, p.rms)
        envelope = min(1.0, n / (0.025 * sample_rate), (total_samples - n) / (0.04 * sample_rate))
        sample = math.sin(phase)
        if harmonics:
            sample += 0.34 * math.sin(phase * 2.0 + 0.15)
            sample += 0.18 * math.sin(phase * 3.0 + 0.31)
            sample += 0.08 * math.sin(phase * 4.0 + 0.11)
        samples.append(sample * amp * max(0.0, envelope))
    return samples


def trace_to_corrected_points(trace: Sequence[dict]) -> list[PitchPoint]:
    return [
        PitchPoint(
            time=float(row["time"]),
            hz=float(row.get("corrected_hz") or 0.0),
            confidence=float(row.get("confidence") or 0.0),
            rms=float(row.get("rms") or 0.8),
        )
        for row in trace
    ]


def hann_window(size: int) -> list[float]:
    if size <= 1:
        return [1.0] * max(0, size)
    return [0.5 - 0.5 * math.cos(2.0 * math.pi * n / (size - 1)) for n in range(size)]


def sample_at(samples: Sequence[float], pos: float) -> float:
    if not samples:
        return 0.0
    if pos <= 0:
        return float(samples[0])
    if pos >= len(samples) - 1:
        return float(samples[-1])
    left = int(math.floor(pos))
    frac = pos - left
    return float(samples[left]) * (1.0 - frac) + float(samples[left + 1]) * frac


def trace_pitch_ratio(row: dict, *, max_ratio: float = 1.42) -> float:
    """Return bounded pitch-shift ratio from a trace row.

    A ratio above 1.0 raises pitch; below 1.0 lowers it. Corrections are already
    softened by style/adaptive/Do No Harm logic before this function runs. The
    bound prevents a bad detector frame from tearing a local grain too far.
    """

    if row_is_copy_protected(row):
        return 1.0
    source_hz = float(row.get("source_hz") or 0.0)
    corrected_hz = float(row.get("corrected_hz") or 0.0)
    confidence = float(row.get("confidence") or 0.0)
    if source_hz <= 0.0 or corrected_hz <= 0.0 or confidence <= 0.02:
        return 1.0
    ratio = corrected_hz / source_hz
    lo = 1.0 / max_ratio
    return max(lo, min(max_ratio, ratio))


def refine_pitch_mark_center(
    samples: Sequence[float],
    approx_center: float,
    sample_rate: int,
    source_hz: float,
    *,
    search_cycles: float = 0.45,
) -> float:
    """Return a lightweight pitch-mark center near ``approx_center``.

    Full PSOLA needs a robust pitch-mark tracker. This dependency-free bridge
    takes one safe step in that direction: for voiced frames, center the grain on
    the strongest local waveform peak within roughly half a source period. The
    goal is not perfect glottal-closure detection; it is to reduce frame-to-frame
    phase jitter and clicks before the later full PSOLA engine lands.
    """

    if not samples or source_hz <= 0.0 or sample_rate <= 0:
        return approx_center

    period = sample_rate / max(40.0, source_hz)
    radius = max(2, int(round(period * search_cycles)))
    center = int(round(approx_center))
    start = max(1, center - radius)
    end = min(len(samples) - 2, center + radius)
    if end <= start:
        return approx_center

    best = center
    best_score = -1.0
    for idx in range(start, end + 1):
        # Prefer strong, locally stable peaks. The small neighbor term keeps the
        # mark from locking to a one-sample spike in noisy/breathy material.
        score = abs(float(samples[idx])) + 0.35 * abs(float(samples[idx - 1])) + 0.35 * abs(float(samples[idx + 1]))
        if score > best_score:
            best_score = score
            best = idx
    return float(best)


def render_granular_audio_samples(
    samples: Sequence[float],
    sample_rate: int,
    trace: Sequence[dict],
    *,
    frame_ms: float = 46.0,
    hop_ms: float = 20.0,
) -> list[float]:
    """Experimental source-audio pitch correction via fixed-size granular overlap-add.

    This is deliberately dependency-free so Armon can install/test it locally.
    For each pitch trace frame, it windows a grain from the original WAV and
    locally resamples around the grain center according to corrected/source
    pitch ratio, then overlap-adds back to the original timeline. The output is
    the original audio timbre, not an oscillator guide, but artifacts are expected
    on polyphonic/noisy material and big jumps.
    """

    if not samples:
        return []
    if not trace:
        return [float(s) for s in samples]

    frame_size = max(64, int(sample_rate * frame_ms / 1000.0))
    hop_size = max(32, int(sample_rate * hop_ms / 1000.0))
    half = frame_size / 2.0
    window = hann_window(frame_size)
    out = [0.0 for _ in range(len(samples))]
    norm = [0.0 for _ in range(len(samples))]

    for row in trace:
        start = int(round(float(row.get("time") or 0.0) * sample_rate))
        # Fall back to hop-aligned starts if a trace has rounded/non-monotonic
        # times; this keeps external CSV traces stable enough for smoke tests.
        if start < 0:
            continue
        ratio = trace_pitch_ratio(row)
        source_center = start + half
        for i, win in enumerate(window):
            dst = start + i
            if dst < 0 or dst >= len(out):
                continue
            rel = i - half
            src_pos = source_center + rel * ratio
            out[dst] += sample_at(samples, src_pos) * win
            norm[dst] += win

    # Preserve uncovered tails/edges from the source. Covered samples are
    # normalized by overlap weight so ratio=1 is close to identity.
    rendered: list[float] = []
    for idx, src in enumerate(samples):
        if norm[idx] > 1e-8:
            rendered.append(out[idx] / norm[idx])
        else:
            rendered.append(float(src))
    return rendered


def render_psola_lite_audio_samples(
    samples: Sequence[float],
    sample_rate: int,
    trace: Sequence[dict],
    *,
    min_window_ms: float = 8.0,
    max_window_ms: float = 42.0,
    cycles: float = 2.75,
) -> list[float]:
    """Dependency-free pitch-synchronous overlap-add renderer.

    This is not full PSOLA: it does not yet run a robust pitch-mark tracker or
    formant-safe transient model. It is a safer next engine step than fixed
    grains because each analysis window follows the detected source period and
    is lightly re-centered onto a nearby waveform peak. Monophonic vocal
    material gets shorter windows on high notes and longer windows on low notes,
    reducing the most obvious fixed-window smearing while keeping the current
    trace/control contract unchanged.
    """

    if not samples:
        return []
    if not trace:
        return [float(s) for s in samples]

    min_size = max(64, int(sample_rate * min_window_ms / 1000.0))
    max_size = max(min_size, int(sample_rate * max_window_ms / 1000.0))
    out = [0.0 for _ in range(len(samples))]
    norm = [0.0 for _ in range(len(samples))]

    for row in trace:
        time = float(row.get("time") or 0.0)
        source_hz = float(row.get("source_hz") or 0.0)
        confidence = float(row.get("confidence") or 0.0)
        rms = float(row.get("rms") or 0.0)
        if source_hz <= 0.0 or confidence <= 0.02 or rms <= 0.001:
            continue

        period = sample_rate / max(40.0, source_hz)
        frame_size = int(round(period * cycles))
        frame_size = max(min_size, min(max_size, frame_size))
        if frame_size % 2:
            frame_size += 1
        half = frame_size / 2.0
        window = hann_window(frame_size)
        ratio = trace_pitch_ratio(row, max_ratio=1.32)

        # Treat row time as the analysis/synthesis center. Using center-aligned,
        # period-sized grains avoids the 46 ms fixed-grain smear on high notes.
        dst_center = time * sample_rate
        pitch_mark = refine_pitch_mark_center(samples, dst_center, sample_rate, source_hz)
        # Keep the v0.5 renderer conservative: full peak-locking without a real
        # synthesis pitch-mark train can over-shift phase on simple material.
        # Nudge toward the local mark instead of hard-snapping to it.
        alignment_strength = 0.06 if confidence >= 0.7 else 0.03
        src_center = dst_center + (pitch_mark - dst_center) * alignment_strength
        dst_start = int(round(dst_center - half))
        for i, win in enumerate(window):
            dst = dst_start + i
            if dst < 0 or dst >= len(out):
                continue
            rel = i - half
            src_pos = src_center + rel * ratio
            out[dst] += sample_at(samples, src_pos) * win
            norm[dst] += win

    rendered: list[float] = []
    for idx, src in enumerate(samples):
        if norm[idx] > 1e-8:
            rendered.append(out[idx] / norm[idx])
        else:
            rendered.append(float(src))
    return rendered


def copy_protected_regions(
    source: Sequence[float],
    rendered: Sequence[float],
    sample_rate: int,
    trace: Sequence[dict],
    *,
    fade_ms: float = 6.0,
    pad_ms: float = 8.0,
) -> list[float]:
    """Blend copy-protected trace regions back to the source audio.

    Guardrail segmentation is allowed to be conservative. If a frame is labeled
    consonant/breath/silence/unvoiced, the renderer should not invent a pitch
    shift there, even if neighboring voiced grains overlap it. This post-pass
    creates a soft mask from protected frames and copies the original recording
    through those regions.
    """

    if not source or not rendered:
        return [float(s) for s in rendered]
    n = min(len(source), len(rendered))
    protected = [0.0 for _ in range(n)]
    times = [float(row.get("time") or 0.0) for row in trace]
    positive_hops = [b - a for a, b in zip(times, times[1:]) if b > a]
    hop = statistics.median(positive_hops) if positive_hops else 0.02
    fade = max(1, int(round(sample_rate * fade_ms / 1000.0)))
    pad = max(0, int(round(sample_rate * pad_ms / 1000.0)))

    for idx, row in enumerate(trace):
        if not row_is_copy_protected(row):
            continue
        start_time = times[idx] if idx < len(times) else 0.0
        end_time = times[idx + 1] if idx + 1 < len(times) and times[idx + 1] > start_time else start_time + hop
        start = max(0, int(round(start_time * sample_rate)) - pad - fade)
        core_start = max(0, int(round(start_time * sample_rate)) - pad)
        core_end = min(n, int(round(end_time * sample_rate)) + pad)
        end = min(n, core_end + fade)
        for sample_idx in range(start, end):
            if core_start <= sample_idx < core_end:
                weight = 1.0
            elif sample_idx < core_start:
                weight = 1.0 - (core_start - sample_idx) / fade
            else:
                weight = 1.0 - (sample_idx - core_end + 1) / fade
            if weight > protected[sample_idx]:
                protected[sample_idx] = max(0.0, min(1.0, weight))

    out: list[float] = []
    for idx in range(n):
        weight = protected[idx]
        out.append(float(rendered[idx]) * (1.0 - weight) + float(source[idx]) * weight)
    if len(rendered) > n:
        out.extend(float(x) for x in rendered[n:])
    return out


def render_corrected_audio_samples(
    samples: Sequence[float],
    sample_rate: int,
    trace: Sequence[dict],
    *,
    engine: str = "psola-lite",
) -> list[float]:
    """Render corrected source audio using the selected local engine."""

    normalized = engine.strip().lower().replace("_", "-")
    if normalized in {"psola", "psola-lite", "pitch-sync", "pitch-synchronous"}:
        rendered = render_psola_lite_audio_samples(samples, sample_rate, trace)
        return copy_protected_regions(samples, rendered, sample_rate, trace)
    if normalized in {"granular", "fixed-grain", "v0.4"}:
        rendered = render_granular_audio_samples(samples, sample_rate, trace)
        return copy_protected_regions(samples, rendered, sample_rate, trace)
    raise ValueError(f"Unsupported render engine: {engine}. Try psola-lite or granular")


def render_quality_metrics(source: Sequence[float], rendered: Sequence[float]) -> dict:
    """Small objective gate for render-engine comparisons.

    These metrics do not prove vocal quality, but they catch broken renders and
    make A/B runs reproducible before a manual listening pass.
    """

    n = min(len(source), len(rendered))
    if n <= 0:
        return {"samples": 0, "duration_delta_samples": len(rendered) - len(source)}

    src_rms = math.sqrt(sum(float(x) * float(x) for x in source[:n]) / n)
    out_rms = math.sqrt(sum(float(x) * float(x) for x in rendered[:n]) / n)
    diff_rms = math.sqrt(sum((float(a) - float(b)) ** 2 for a, b in zip(source[:n], rendered[:n])) / n)
    peak = max(abs(float(x)) for x in rendered[:n]) if rendered else 0.0
    clip_risk_samples = sum(1 for x in rendered if abs(float(x)) >= 0.999)
    return {
        "samples": n,
        "duration_delta_samples": len(rendered) - len(source),
        "source_rms": round(src_rms, 6),
        "rendered_rms": round(out_rms, 6),
        "rms_ratio": round(out_rms / src_rms, 4) if src_rms > 1e-12 else None,
        "diff_rms": round(diff_rms, 6),
        "peak_abs": round(peak, 6),
        "clip_risk_samples": clip_risk_samples,
    }


def detect_pitch_frame(frame: Sequence[float], sample_rate: int, min_hz: float, max_hz: float) -> tuple[float, float, float]:
    if not frame:
        return 0.0, 0.0, 0.0
    mean = sum(frame) / len(frame)
    centered = [x - mean for x in frame]
    rms = math.sqrt(sum(x * x for x in centered) / len(centered))
    if rms < 0.006:
        return 0.0, 0.0, rms

    min_lag = max(1, int(sample_rate / max_hz))
    max_lag = min(len(centered) - 2, int(sample_rate / min_hz))
    if max_lag <= min_lag:
        return 0.0, 0.0, rms

    best_lag = min_lag
    best_corr = -1.0
    # Normalized autocorrelation. v0 speed is okay for short demo/offline traces.
    for lag in range(min_lag, max_lag + 1):
        num = 0.0
        a2 = 0.0
        b2 = 0.0
        limit = len(centered) - lag
        for i in range(limit):
            a = centered[i]
            b = centered[i + lag]
            num += a * b
            a2 += a * a
            b2 += b * b
        denom = math.sqrt(a2 * b2) + 1e-12
        corr = num / denom
        if corr > best_corr:
            best_corr = corr
            best_lag = lag

    hz = sample_rate / best_lag
    # Penalize octave-ish uncertainty by comparing local prominence.
    confidence = max(0.0, min(1.0, (best_corr - 0.35) / 0.6))
    # Autocorrelation can be overconfident on quiet synthetic/noisy regions.
    # Fold in energy so Do No Harm gets exercised on breathy/ambiguous frames.
    confidence *= max(0.0, min(1.0, rms / 0.16))
    return hz, confidence, rms


def detect_pitch_contour(
    samples: Sequence[float],
    sample_rate: int,
    *,
    frame_ms: float = 46.0,
    hop_ms: float = 20.0,
    min_hz: float = 80.0,
    max_hz: float = 900.0,
) -> list[PitchPoint]:
    frame_size = max(64, int(sample_rate * frame_ms / 1000.0))
    hop_size = max(32, int(sample_rate * hop_ms / 1000.0))
    points: list[PitchPoint] = []
    if len(samples) < frame_size:
        return points
    for start in range(0, len(samples) - frame_size + 1, hop_size):
        frame = samples[start : start + frame_size]
        hz, confidence, rms = detect_pitch_frame(frame, sample_rate, min_hz, max_hz)
        points.append(PitchPoint(time=start / sample_rate, hz=hz, confidence=confidence, rms=min(1.0, rms * 4.0)))
    return points


def write_trace(path: Path, document: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, indent=2) + "\n")


def safe_slug(value: str) -> str:
    chars: list[str] = []
    for ch in value.strip().lower():
        if ch.isalnum():
            chars.append(ch)
        elif ch in {"-", "_", "."}:
            chars.append(ch)
        elif ch.isspace() or ch in {"/", "\\", ":"}:
            chars.append("-")
    slug = "".join(chars).strip("-._")
    return slug or "clip"


def load_corpus_manifest(path: Path) -> dict:
    with path.open() as f:
        manifest = json.load(f)
    if isinstance(manifest, list):
        manifest = {"clips": manifest}
    if not isinstance(manifest, dict):
        raise ValueError("Corpus manifest must be a JSON object with a clips array")
    return manifest


def validate_corpus_manifest(manifest: dict) -> list[dict]:
    clips = manifest.get("clips")
    if not isinstance(clips, list) or not clips:
        raise ValueError("Corpus manifest must include a non-empty clips array")

    seen_ids: set[str] = set()
    validated: list[dict] = []
    for idx, clip in enumerate(clips):
        if not isinstance(clip, dict):
            raise ValueError(f"clips[{idx}] must be an object")
        missing = [field for field in MANIFEST_REQUIRED_CLIP_FIELDS if field not in clip]
        if missing:
            raise ValueError(f"clips[{idx}] is missing required fields: {', '.join(missing)}")

        clip_id = str(clip["clip_id"]).strip()
        if not clip_id:
            raise ValueError(f"clips[{idx}].clip_id must not be empty")
        if clip_id in seen_ids:
            raise ValueError(f"Duplicate clip_id in manifest: {clip_id}")
        seen_ids.add(clip_id)

        status = str(clip["permission_status"]).strip().lower().replace("_", "-")
        if status not in ALLOWED_PERMISSION_STATUSES:
            raise ValueError(
                f"clips[{idx}] permission_status={clip['permission_status']!r} is not allowed; "
                f"use one of {', '.join(sorted(ALLOWED_PERMISSION_STATUSES))}"
            )
        if clip.get("cleared_for_internal_eval") is not True:
            raise ValueError(f"clips[{idx}] must set cleared_for_internal_eval=true before batch evaluation")
        if bool(clip.get("public_release_allowed", False)) and status == "synthetic-fixture":
            raise ValueError(f"clips[{idx}] synthetic fixtures must not set public_release_allowed=true")

        normalized = dict(clip)
        normalized["clip_id"] = clip_id
        normalized["permission_status"] = status
        validated.append(normalized)
    return validated


def parse_expected_key(value: object) -> tuple[str | None, str | None]:
    """Return (root, scale), or (None, None) for auto-key."""

    if isinstance(value, dict):
        if value.get("auto") is True:
            return None, None
        root = value.get("root")
        scale = value.get("scale")
        if root and scale:
            return str(root), str(scale)
        raise ValueError("expected_key object must be {'auto': true} or include root and scale")
    text = str(value).strip()
    if not text or text.lower() in {"auto", "auto-key", "unknown"}:
        return None, None
    parts = text.replace("/", " ").replace("-", " ").split()
    if len(parts) == 2:
        root, scale = parts
        # Validate early for clearer manifest errors.
        parse_root(root)
        if scale not in SCALES:
            raise ValueError(f"Unsupported expected_key scale: {scale}")
        return root, scale
    raise ValueError("expected_key must be 'auto', {'root': 'A', 'scale': 'minor'}, or 'A minor'")


def manifest_list(value: object, *, fallback: Sequence[str]) -> list[str]:
    if value is None:
        return list(fallback)
    if isinstance(value, str):
        if value.strip().lower() in {"all", "default", "defaults"}:
            return list(fallback)
        return [item.strip() for item in value.split(",") if item.strip()]
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    raise ValueError("Expected a comma string or list")


def resolve_manifest_source(clip: dict, manifest_path: Path, out_dir: Path) -> Path:
    raw = str(clip["source_path"]).strip()
    if raw in {"__synthetic_generated_demo__", "__generated_demo__"}:
        fixture_dir = out_dir / "_fixtures"
        fixture_path = fixture_dir / f"{safe_slug(clip['clip_id'])}-synthetic-vocalish.wav"
        if not fixture_path.exists():
            write_wav_mono(fixture_path, DEFAULT_SAMPLE_RATE, contour_to_samples(generated_demo_contour()))
        return fixture_path
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = manifest_path.parent / path
    return path


def write_listening_review_csv(path: Path, rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=LISTENING_REVIEW_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({col: row.get(col, "") for col in LISTENING_REVIEW_COLUMNS})


def write_listening_review_markdown(path: Path, rows: Sequence[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    header = "| " + " | ".join(LISTENING_REVIEW_COLUMNS) + " |"
    separator = "| " + " | ".join("---" for _ in LISTENING_REVIEW_COLUMNS) + " |"
    lines = [
        "# Auto Pitch Corpus Listening Review",
        "",
        "Internal-only review sheet. Use owned/cleared audio only; do not treat these renders as sale-ready.",
        "",
        "Score columns use 1–5 where 5 is best, except `artifact_severity_1_5` where 1 is clean/minor and 5 is severe.",
        "",
        header,
        separator,
    ]
    for row in rows:
        cells = [str(row.get(col, "")).replace("|", "\\|") for col in LISTENING_REVIEW_COLUMNS]
        lines.append("| " + " | ".join(cells) + " |")
    lines.append("")
    path.write_text("\n".join(lines))


def run_batch_evaluate(
    manifest_path: Path,
    out_dir: Path,
    *,
    styles: Sequence[str] | None = None,
    render_engines: Sequence[str] | None = None,
) -> dict:
    manifest_path = manifest_path.expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = load_corpus_manifest(manifest_path)
    clips = validate_corpus_manifest(manifest)
    defaults = manifest.get("defaults", {}) if isinstance(manifest.get("defaults", {}), dict) else {}
    default_styles = [normalize_style(s) for s in (styles or manifest_list(defaults.get("styles"), fallback=list(STYLE_PRESETS)))]
    default_engines = [str(e).strip().lower().replace("_", "-") for e in (render_engines or manifest_list(defaults.get("render_engines"), fallback=["psola-lite", "granular"]))]
    for engine in default_engines:
        if engine not in {"psola-lite", "granular"}:
            raise ValueError(f"Unsupported render engine in batch: {engine}")

    trace_dir = out_dir / "traces"
    guide_dir = out_dir / "guides"
    wav_dir = out_dir / "wavs"
    metrics_dir = out_dir / "metrics"
    review_rows: list[dict] = []
    outputs: list[dict] = []

    for clip in clips:
        source_path = resolve_manifest_source(clip, manifest_path, out_dir)
        if not source_path.exists():
            raise FileNotFoundError(f"Source WAV for clip_id={clip['clip_id']} does not exist: {source_path}")
        sample_rate, samples = read_wav_mono(source_path)
        points = detect_pitch_contour(samples, sample_rate)
        clip_slug = safe_slug(str(clip["clip_id"]))
        clip_styles = [normalize_style(s) for s in manifest_list(clip.get("style_target"), fallback=default_styles)]
        clip_engines = [str(e).strip().lower().replace("_", "-") for e in manifest_list(clip.get("render_engines"), fallback=default_engines)]
        expected_root, expected_scale = parse_expected_key(clip.get("expected_key"))

        for style in clip_styles:
            if expected_root is None or expected_scale is None:
                doc = build_trace_document(points, root=None, scale=None, style=style, source=str(source_path))
            else:
                doc = build_trace_document(points, root=expected_root, scale=expected_scale, style=style, source=str(source_path))
            doc.setdefault("corpus_clip", {}).update(
                {
                    "clip_id": clip["clip_id"],
                    "permission_status": clip["permission_status"],
                    "voice_range": clip["voice_range"],
                    "known_challenges": clip.get("known_challenges", []),
                    "public_release_allowed": bool(clip.get("public_release_allowed", False)),
                    "notes": clip.get("notes", ""),
                }
            )
            protection_summary = trace_protection_summary(doc["trace"])
            trace_path = trace_dir / f"{clip_slug}-{style}-trace.json"
            guide_path = guide_dir / f"{clip_slug}-{style}-guide.wav"
            write_trace(trace_path, doc)
            write_wav_mono(guide_path, sample_rate, contour_to_samples(trace_to_corrected_points(doc["trace"]), sample_rate))

            for engine in clip_engines:
                corrected = render_corrected_audio_samples(samples, sample_rate, doc["trace"], engine=engine)
                wav_path = wav_dir / f"{clip_slug}-{style}-{engine}.wav"
                metrics_path = metrics_dir / f"{clip_slug}-{style}-{engine}-metrics.json"
                write_wav_mono(wav_path, sample_rate, corrected)
                metrics = {
                    "clip_id": clip["clip_id"],
                    "source_path": str(source_path),
                    "trace_path": str(trace_path),
                    "guide_wav_path": str(guide_path),
                    "corrected_wav_path": str(wav_path),
                    "style": style,
                    "render_engine": engine,
                    "permission_status": clip["permission_status"],
                    "protection_summary": protection_summary,
                    "metrics": render_quality_metrics(samples, corrected),
                }
                write_trace(metrics_path, metrics)
                output_row = {
                    "clip_id": clip["clip_id"],
                    "voice_range": clip["voice_range"],
                    "source_path": str(source_path),
                    "expected_key": json.dumps(clip.get("expected_key"), separators=(",", ":")) if isinstance(clip.get("expected_key"), dict) else str(clip.get("expected_key")),
                    "style": style,
                    "render_engine": engine,
                    "trace_path": str(trace_path),
                    "guide_wav_path": str(guide_path),
                    "corrected_wav_path": str(wav_path),
                    "metrics_path": str(metrics_path),
                    "segment_mix": json.dumps(protection_summary["segment_counts"], separators=(",", ":")),
                    "protected_region_count": protection_summary["protected_region_count"],
                    "protection_flags": ",".join(sorted(protection_summary["protection_flag_counts"])),
                    "artifact_review_required": "yes" if protection_summary["artifact_review_required"] else "no",
                }
                review_rows.append(output_row)
                outputs.append({**output_row, "protection_summary": protection_summary, "metrics": metrics["metrics"]})

    review_csv = out_dir / "listening-review.csv"
    review_md = out_dir / "listening-review.md"
    write_listening_review_csv(review_csv, review_rows)
    write_listening_review_markdown(review_md, review_rows)
    summary = {
        "truth_label": "internal prototype/R&D; not sale-ready",
        "manifest": str(manifest_path),
        "out_dir": str(out_dir),
        "clip_count": len(clips),
        "output_count": len(outputs),
        "styles": default_styles,
        "render_engines": default_engines,
        "review_csv": str(review_csv),
        "review_markdown": str(review_md),
        "outputs": outputs,
    }
    write_trace(out_dir / "batch-summary.json", summary)
    return summary


def run_demo(out_dir: Path, root: str, scale: str, styles: Sequence[str]) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    points = generated_demo_contour()
    source_wav = out_dir / "demo-source-vocalish.wav"
    write_wav_mono(source_wav, DEFAULT_SAMPLE_RATE, contour_to_samples(points))

    # Also prove the WAV path by detecting from the generated source, then use
    # detected points for trace/render artifacts.
    sample_rate, samples = read_wav_mono(source_wav)
    detected = detect_pitch_contour(samples, sample_rate)
    for style in styles:
        doc = build_trace_document(detected, root=root, scale=scale, style=style, source=str(source_wav))
        trace_path = out_dir / f"demo-{normalize_style(style)}-trace.json"
        write_trace(trace_path, doc)
        guide = contour_to_samples(trace_to_corrected_points(doc["trace"]), sample_rate)
        write_wav_mono(out_dir / f"demo-{normalize_style(style)}-guide.wav", sample_rate, guide)
        corrected = render_corrected_audio_samples(samples, sample_rate, doc["trace"])
        write_wav_mono(out_dir / f"demo-{normalize_style(style)}-corrected.wav", sample_rate, corrected)
    print(f"Wrote demo source + {len(styles)} style traces/guides to {out_dir}")


def run_adapt_demo(out_dir: Path, style: str, *, window_seconds: float = 1.0, min_section_seconds: float = 0.9) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    style = normalize_style(style)
    points = generated_adapt_demo_contour()
    source_wav = out_dir / "demo-adapt-source-vocalish.wav"
    write_wav_mono(source_wav, DEFAULT_SAMPLE_RATE, contour_to_samples(points))
    doc = build_adapt_trace_document(
        points,
        style=style,
        source=str(source_wav),
        window_seconds=window_seconds,
        min_section_seconds=min_section_seconds,
    )
    trace_path = out_dir / f"demo-adapt-{style}-trace.json"
    key_map_path = out_dir / "demo-adapt-key-map.json"
    write_trace(trace_path, doc)
    write_trace(key_map_path, doc["adapt_key_map"])
    guide = contour_to_samples(trace_to_corrected_points(doc["trace"]), DEFAULT_SAMPLE_RATE)
    write_wav_mono(out_dir / f"demo-adapt-{style}-guide.wav", DEFAULT_SAMPLE_RATE, guide)
    source_rate, source_samples = read_wav_mono(source_wav)
    corrected = render_corrected_audio_samples(source_samples, source_rate, doc["trace"])
    write_wav_mono(out_dir / f"demo-adapt-{style}-corrected.wav", source_rate, corrected)
    print(
        f"Wrote Adapt demo source, key map, {style} trace/guide to {out_dir} "
        f"({len(doc['adapt_key_map']['sections'])} sections)"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Auto Pitch v0 offline prototype harness")
    parser.add_argument("command", nargs="?", choices=["batch-evaluate"], help="Optional command; use batch-evaluate for corpus manifests")
    parser.add_argument("--input-csv", type=Path, help="CSV with time,hz,confidence[,rms] columns")
    parser.add_argument("--input-wav", type=Path, help="Mono/stereo 16-bit PCM WAV to analyze")
    parser.add_argument("--manifest", type=Path, help="Corpus manifest JSON for batch-evaluate")
    parser.add_argument("--demo", action="store_true", help="Generate source demo WAV, traces, and guide renders")
    parser.add_argument("--root", default="A", help="Root note, or omit with --auto-key")
    parser.add_argument("--scale", default="minor", choices=sorted(SCALES))
    parser.add_argument("--auto-key", action="store_true", help="Use estimated key/scale instead of --root/--scale")
    parser.add_argument("--adapt", action="store_true", help="Offline Adapt Mode: detect key zones and correct per section")
    parser.add_argument("--adapt-window-seconds", type=float, default=1.0, help="Adapt key-estimation window length")
    parser.add_argument("--adapt-min-section-seconds", type=float, default=0.9, help="Adapt short-section merge threshold")
    parser.add_argument("--style", default="modern", choices=sorted(STYLE_PRESETS))
    parser.add_argument("--styles", default="natural,modern,hard", help="Comma styles for --demo")
    parser.add_argument("--batch-styles", default=None, help="Comma styles for batch-evaluate (default: manifest or natural,modern,hard)")
    parser.add_argument("--out", type=Path, default=Path("pitch_trace.json"))
    parser.add_argument("--render-guide-wav", type=Path, help="Write corrected pitch-guide WAV from trace")
    parser.add_argument(
        "--render-corrected-wav",
        type=Path,
        help="Experimental: write source-audio pitch-corrected WAV using dependency-free overlap-add",
    )
    parser.add_argument(
        "--render-engine",
        default="psola-lite",
        choices=["psola-lite", "granular"],
        help="Source-audio correction engine for --render-corrected-wav",
    )
    parser.add_argument("--render-metrics", type=Path, help="Write objective source-vs-render metrics JSON")
    parser.add_argument("--render-engines", default=None, help="Comma render engines for batch-evaluate (default: manifest or psola-lite,granular)")
    parser.add_argument("--out-dir", type=Path, default=Path("out"), help="Directory for --demo artifacts")
    args = parser.parse_args()

    if args.command == "batch-evaluate":
        if not args.manifest:
            parser.error("batch-evaluate requires --manifest")
        batch_styles = [s.strip() for s in args.batch_styles.split(",") if s.strip()] if args.batch_styles else None
        batch_engines = [e.strip() for e in args.render_engines.split(",") if e.strip()] if args.render_engines else None
        summary = run_batch_evaluate(args.manifest, args.out_dir, styles=batch_styles, render_engines=batch_engines)
        print(json.dumps({k: v for k, v in summary.items() if k != "outputs"}, indent=2))
        return

    if args.demo:
        if args.adapt:
            run_adapt_demo(
                args.out_dir,
                args.style,
                window_seconds=args.adapt_window_seconds,
                min_section_seconds=args.adapt_min_section_seconds,
            )
            return
        run_demo(args.out_dir, args.root, args.scale, [s.strip() for s in args.styles.split(",") if s.strip()])
        return

    source = "generated_demo_contour"
    if args.input_wav:
        sample_rate, samples = read_wav_mono(args.input_wav)
        points = detect_pitch_contour(samples, sample_rate)
        source = str(args.input_wav)
    elif args.input_csv:
        points = load_csv(args.input_csv)
        sample_rate = DEFAULT_SAMPLE_RATE
        source = str(args.input_csv)
    else:
        points = generated_demo_contour()
        sample_rate = DEFAULT_SAMPLE_RATE

    if args.adapt:
        doc = build_adapt_trace_document(
            points,
            style=args.style,
            source=source,
            window_seconds=args.adapt_window_seconds,
            min_section_seconds=args.adapt_min_section_seconds,
        )
    else:
        root = None if args.auto_key else args.root
        scale = None if args.auto_key else args.scale
        doc = build_trace_document(points, root=root, scale=scale, style=args.style, source=source)
    write_trace(args.out, doc)
    if args.adapt:
        key_map_out = args.out.with_name(args.out.stem + "-adapt-key-map.json")
        write_trace(key_map_out, doc["adapt_key_map"])
    if args.render_guide_wav:
        write_wav_mono(args.render_guide_wav, sample_rate, contour_to_samples(trace_to_corrected_points(doc["trace"]), sample_rate))
    if args.render_corrected_wav:
        if args.input_wav:
            source_for_metrics = samples
            corrected = render_corrected_audio_samples(samples, sample_rate, doc["trace"], engine=args.render_engine)
        else:
            # For generated/CSV traces there is no original recording, so create
            # a source guide from the contour and still exercise the real-audio
            # renderer path against non-corrected source samples.
            source_samples = contour_to_samples(points, sample_rate)
            source_for_metrics = source_samples
            corrected = render_corrected_audio_samples(source_samples, sample_rate, doc["trace"], engine=args.render_engine)
        write_wav_mono(args.render_corrected_wav, sample_rate, corrected)
        if args.render_metrics:
            metrics = {
                "render_engine": args.render_engine,
                "source": source,
                "output": str(args.render_corrected_wav),
                "metrics": render_quality_metrics(source_for_metrics, corrected),
            }
            write_trace(args.render_metrics, metrics)
    print(f"Wrote {args.out} with {len(doc['trace'])} pitch points")
    status = {"settings": doc["settings"], "summary": doc["summary"]}
    if args.adapt:
        status["adapt_key_map"] = doc["adapt_key_map"]
    else:
        status["key_suggestion"] = doc["key_suggestion"]
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
