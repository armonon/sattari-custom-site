# Sattari Auto Pitch / AutoKey Tester v0.6

This is the offline tester for Auto Pitch + AutoKey logic. It is for internal testing, not a finished commercial plugin.

## What to test

- AutoKey: suggests key/scale from a monophonic vocal WAV.
- Auto Pitch styles: Natural, Modern, Hard.
- Experimental corrected WAV rendering.
- Pitch Compass UI demo in `ui/index.html`.

## Fastest path

Double-click `scripts/run_demo.command` to generate demo outputs.

To process your own vocal, drag a 16-bit PCM WAV file onto `scripts/process_wav.command`.

Outputs go into the `out/` folder:

- `*-trace.json` — key, pitch, confidence, and correction trace
- `*-guide.wav` — pitch guide synth/resynthesis
- `*-corrected.wav` — experimental corrected source-audio render
- `*-render-metrics.json` — sanity metrics

## Important limitation

This is not final vocal-quality proof yet. The offline renderer is a dependency-free PSOLA-lite/granular prototype, so artifacts are expected on real vocals. Use it to test the direction and AutoKey behavior, not as a finished mix-ready tuner.
