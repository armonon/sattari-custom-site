#!/usr/bin/env python3
"""Regression tests for the Auto Pitch v0 prototype harness."""

from pathlib import Path
import json
import tempfile
import unittest

import pitch_logic as p


class AutoPitchLogicTests(unittest.TestCase):
    def test_nearest_allowed_quantizes_to_scale(self):
        allowed = p.allowed_pitch_classes("A", "minor")
        # C#4 is outside A minor and should pull to C4 or D4, not remain C#.
        target = p.nearest_allowed_midi(61.0, allowed)
        self.assertIn(target % 12, allowed)
        self.assertIn(p.note_name(target), {"C4", "D4"})

    def test_low_confidence_do_no_harm_reduces_hard_tune_strength(self):
        points = [p.PitchPoint(time=0.0, hz=226.0, confidence=0.06)]
        row = p.correct_contour(points, root="A", scale="minor", style="hard")[0]
        self.assertLess(row["do_no_harm_strength"], 0.30)
        self.assertIn("low_confidence_do_no_harm", row["guardrails"])

    def test_segmentation_marks_unvoiced_regions_for_source_copy_protection(self):
        points = [
            p.PitchPoint(time=0.00, hz=220.0, confidence=0.92, rms=0.8),
            p.PitchPoint(time=0.02, hz=0.0, confidence=0.0, rms=0.004),
            p.PitchPoint(time=0.04, hz=0.0, confidence=0.05, rms=0.055),
            p.PitchPoint(time=0.06, hz=0.0, confidence=0.04, rms=0.20),
        ]
        rows = p.correct_contour(points, root="A", scale="minor", style="modern")
        self.assertEqual(rows[0]["segment_label"], "voiced")
        self.assertEqual(rows[1]["segment_label"], "silence")
        self.assertEqual(rows[2]["segment_label"], "breath")
        self.assertEqual(rows[3]["segment_label"], "consonant")
        for row in rows[1:]:
            self.assertEqual(row["render_action"], "copy_source")
            self.assertIn("copy_source", row["protection_flags"])
            self.assertIn("copy_source", row["guardrails"])

    def test_copy_protected_regions_restores_source_audio_under_guardrail_mask(self):
        source = [0.25 if i % 2 == 0 else -0.25 for i in range(120)]
        rendered = [0.0 for _ in source]
        trace = [
            {"time": 0.00, "protection_flags": [], "render_action": "pitch_shift"},
            {"time": 0.02, "protection_flags": ["copy_source", "protect_consonant"], "render_action": "copy_source"},
            {"time": 0.04, "protection_flags": [], "render_action": "pitch_shift"},
        ]
        restored = p.copy_protected_regions(source, rendered, sample_rate=1000, trace=trace, fade_ms=1, pad_ms=0)
        self.assertEqual(restored[25], source[25])
        self.assertEqual(restored[35], source[35])
        self.assertEqual(restored[0], rendered[0])

    def test_phrase_reset_prevents_bad_glide_on_big_leap(self):
        points = [
            p.PitchPoint(time=0.0, hz=220.0, confidence=0.9),
            p.PitchPoint(time=0.02, hz=329.6, confidence=0.9),
        ]
        rows = p.correct_contour(points, root="A", scale="minor", style="natural")
        self.assertEqual(rows[1]["phrase_event"], "phrase_reset")
        self.assertGreater(rows[1]["corrected_hz"], 300.0)

    def test_key_estimation_finds_a_minor_family_for_generated_demo(self):
        suggestion = p.estimate_key(p.generated_demo_contour())
        alternatives = {(a["root"], a["scale"]) for a in suggestion["alternatives"]}
        self.assertIn(("A", "minor"), alternatives)

    def test_demo_cli_artifacts_are_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            p.run_demo(out, "A", "minor", ["natural", "modern", "hard"])
            for name in [
                "demo-source-vocalish.wav",
                "demo-natural-trace.json",
                "demo-modern-trace.json",
                "demo-hard-trace.json",
                "demo-natural-guide.wav",
                "demo-modern-guide.wav",
                "demo-hard-guide.wav",
                "demo-natural-corrected.wav",
                "demo-modern-corrected.wav",
                "demo-hard-corrected.wav",
            ]:
                self.assertTrue((out / name).exists(), name)

    def test_experimental_corrected_audio_renderers_preserve_length_and_change_audio(self):
        points = p.generated_demo_contour()
        source = p.contour_to_samples(points, sample_rate=8_000)
        doc = p.build_trace_document(points, root="A", scale="minor", style="hard", source="unit-test")
        for engine in ["psola-lite", "granular"]:
            with self.subTest(engine=engine):
                corrected = p.render_corrected_audio_samples(source, 8_000, doc["trace"], engine=engine)
                metrics = p.render_quality_metrics(source, corrected)
                self.assertEqual(len(corrected), len(source))
                self.assertEqual(metrics["duration_delta_samples"], 0)
                self.assertGreater(sum(abs(x) for x in corrected), 0.1)
                self.assertGreater(sum(abs(a - b) for a, b in zip(source, corrected)), 0.01)
                self.assertLess(metrics["clip_risk_samples"], len(source) * 0.01)

    def test_psola_lite_refines_to_nearby_pitch_mark_peak(self):
        samples = [0.0] * 120
        samples[57] = 0.2
        samples[60] = -0.15
        samples[63] = 0.9
        mark = p.refine_pitch_mark_center(samples, approx_center=60.0, sample_rate=1000, source_hz=100)
        self.assertEqual(mark, 63.0)

    def test_adapt_mode_uses_different_targets_across_key_change(self):
        points = p.generated_adapt_demo_contour()
        doc = p.build_adapt_trace_document(points, style="hard", source="unit-test")
        sections = doc["adapt_key_map"]["sections"]
        self.assertGreaterEqual(len(sections), 2)

        before = next(row for row in doc["trace"] if row["source_hz"] > 0 and row["time"] < sections[0]["end"])
        after = next(row for row in doc["trace"] if row["source_hz"] > 0 and row["time"] >= sections[1]["start"])
        self.assertNotEqual((before["section_root"], before["section_scale"]), (after["section_root"], after["section_scale"]))
        self.assertNotEqual(
            p.allowed_pitch_classes(before["section_root"], before["section_scale"]),
            p.allowed_pitch_classes(after["section_root"], after["section_scale"]),
        )

        # Same-ish D#/Eb source pitch should resolve differently by section:
        # C-major family pulls it toward E/F, while E-major family allows D#.
        manual_points = [
            p.PitchPoint(time=0.2, hz=p.midi_to_hz(63.0), confidence=0.95),
            p.PitchPoint(time=1.2, hz=p.midi_to_hz(63.0), confidence=0.95),
        ]
        key_map = {
            "sections": [
                {"section_id": "adapt_000", "start": 0.0, "end": 1.0, "root": "C", "scale": "major", "confidence": 0.9, "warnings": []},
                {"section_id": "adapt_001", "start": 1.0, "end": 2.0, "root": "E", "scale": "major", "confidence": 0.9, "warnings": []},
            ]
        }
        rows = p.correct_contour_adapt(manual_points, adapt_key_map=key_map, style="hard")
        self.assertNotEqual(rows[0]["target_midi"], rows[1]["target_midi"])

    def test_batch_evaluate_manifest_writes_outputs_and_review_sheet(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            manifest = {
                "version": 1,
                "truth_label": "internal prototype/R&D; not sale-ready",
                "defaults": {"styles": ["modern"], "render_engines": ["psola-lite"]},
                "clips": [
                    {
                        "clip_id": "synthetic_fixture_01",
                        "source_path": "__synthetic_generated_demo__",
                        "permission_status": "synthetic-fixture",
                        "cleared_for_internal_eval": True,
                        "public_release_allowed": False,
                        "voice_range": "synthetic tenor-ish fixture",
                        "expected_key": {"root": "A", "scale": "minor"},
                        "style_target": ["modern"],
                        "known_challenges": ["scoops", "vibrato", "low confidence frame"],
                        "notes": "Generated by the local harness; not a real vocal.",
                    }
                ],
            }
            manifest_path = base / "manifest.json"
            manifest_path.write_text(json.dumps(manifest))
            out_dir = base / "batch-out"

            summary = p.run_batch_evaluate(manifest_path, out_dir)

            self.assertEqual(summary["clip_count"], 1)
            self.assertEqual(summary["output_count"], 1)
            for rel in [
                "traces/synthetic_fixture_01-modern-trace.json",
                "guides/synthetic_fixture_01-modern-guide.wav",
                "wavs/synthetic_fixture_01-modern-psola-lite.wav",
                "metrics/synthetic_fixture_01-modern-psola-lite-metrics.json",
                "listening-review.csv",
                "listening-review.md",
                "batch-summary.json",
            ]:
                self.assertTrue((out_dir / rel).exists(), rel)
            review = (out_dir / "listening-review.csv").read_text()
            self.assertIn("pitch_correctness_1_5", review)
            self.assertIn("protected_region_artifacts_1_5", review)
            self.assertIn("artifact_review_required", review)
            self.assertIn("synthetic_fixture_01", review)

            metrics = json.loads((out_dir / "metrics/synthetic_fixture_01-modern-psola-lite-metrics.json").read_text())
            self.assertIn("protection_summary", metrics)
            self.assertIn("segment_counts", metrics["protection_summary"])

    def test_corpus_manifest_requires_cleared_audio_status(self):
        manifest = {
            "clips": [
                {
                    "clip_id": "bad_clip",
                    "source_path": "bad.wav",
                    "permission_status": "uncleared",
                    "cleared_for_internal_eval": False,
                    "voice_range": "unknown",
                    "expected_key": "auto",
                    "style_target": "modern",
                    "known_challenges": [],
                    "notes": "Should be rejected.",
                }
            ]
        }
        with self.assertRaises(ValueError):
            p.validate_corpus_manifest(manifest)


if __name__ == "__main__":
    unittest.main()
